#!/usr/bin/env bash
# Docker config credential lookup for bundle scripts.

DOCKER_CONFIG_AUTH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Run a configured Docker credential helper and print username/token.
_docker_credential_helper() {
  local host="$1" helper="$2" bin out user secret
  [[ -n "$helper" ]] || return 1
  bin="docker-credential-$helper"
  command -v "$bin" >/dev/null 2>&1 || bin="$bin.exe"
  command -v "$bin" >/dev/null 2>&1 || return 1
  out=$("$bin" get <<<"$host" 2>/dev/null) || return 1
  if command -v jq >/dev/null 2>&1; then
    user=$(printf '%s' "$out" | jq -r '.Username // empty' 2>/dev/null) || return 1
    secret=$(printf '%s' "$out" | jq -r '.Secret // empty' 2>/dev/null) || return 1
  else
    user=$(printf '%s' "$out" | sed -n 's/.*"Username"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
    secret=$(printf '%s' "$out" | sed -n 's/.*"Secret"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p')
  fi
  [[ -n "$user" && -n "$secret" ]] || return 1
  printf '%s\n%s\n' "$user" "$secret"
}

# Read Docker credentials without Python. Prefer jq for correct JSON parsing;
# use the text parser only on minimal hosts where jq is also unavailable.
_docker_config_auth_fallback() {
  local host="$1" cfg="$2" esc b64="" decoded helper="" user secret lhost
  lhost=$(printf '%s' "$host" | tr '[:upper:]' '[:lower:]')
  if command -v jq >/dev/null 2>&1; then
    b64=$(jq -r --arg host "$lhost" '
      def address:
        ascii_downcase | sub("^https?://"; "") | split("/")[0] |
        split("@")[-1] | ascii_downcase;
      first((.auths // {}) | to_entries[] |
        select((.key | address) == $host) | .value.auth? // empty) // empty
    ' "$cfg" 2>/dev/null) || return 1
    helper=$(jq -r --arg host "$lhost" '
      def address:
        ascii_downcase | sub("^https?://"; "") | split("/")[0] |
        split("@")[-1] | ascii_downcase;
      first((.credHelpers // {}) | to_entries[] |
        select((.key | address) == $host and (.value | type) == "string") |
        .value) //
        (if (.credsStore | type) == "string" then .credsStore else empty end)
    ' "$cfg" 2>/dev/null) || return 1
  else
    esc=$(printf '%s' "$host" | sed 's/[][\.*^$]/\\&/g')
    b64=$(grep -E -A3 "\"(https?://)?${esc}([/:][^\"]*)?\"[[:space:]]*:[[:space:]]*\{" "$cfg" 2>/dev/null \
      | sed -n 's/.*"auth"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)
    helper=$(grep -E "\"(https?://)?${esc}([/:][^\"]*)?\"[[:space:]]*:[[:space:]]*\"[^\"]+\"" "$cfg" 2>/dev/null \
      | sed -n 's/.*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -n1)
    [[ -z "$helper" ]] && helper=$(sed -n 's/.*"credsStore"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$cfg" | head -n1)
  fi
  if [[ -n "$b64" ]] && decoded=$(printf '%s' "$b64" | base64 -d 2>/dev/null \
        || printf '%s' "$b64" | base64 -D 2>/dev/null) \
      && [[ "$decoded" == *:* && -n "${decoded%%:*}" && -n "${decoded#*:}" ]]; then
    user="${decoded%%:*}"
    secret="${decoded#*:}"
    printf '%s\n%s\n' "$user" "$secret"
    return 0
  fi
  _docker_credential_helper "$host" "$helper"
}

# Read `docker login` credentials for a host: config.json auths first,
# then the configured credential helper (docker-credential-<name> get).
_docker_config_auth() {
  local host="$1" cfg="${DOCKER_CONFIG:-$HOME/.docker}/config.json"
  [[ -f "$cfg" ]] || return 1
  if ! command -v python3 >/dev/null 2>&1 \
      || [[ ! -f "$DOCKER_CONFIG_AUTH_DIR/docker_config_auth.py" ]]; then
    _docker_config_auth_fallback "$host" "$cfg"
    return
  fi
  python3 "$DOCKER_CONFIG_AUTH_DIR/docker_config_auth.py" "$cfg" "$host"
}
