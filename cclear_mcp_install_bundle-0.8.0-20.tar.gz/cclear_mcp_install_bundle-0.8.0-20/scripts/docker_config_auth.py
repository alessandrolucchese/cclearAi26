#!/usr/bin/env python3
"""Read registry credentials from Docker's config.json."""

import base64
import json
import subprocess
import sys
from urllib.parse import urlsplit


def registry_address(value):
    """Normalize a Docker registry key to a lowercase host[:port]."""
    candidate = value if "://" in value else "//" + value
    try:
        authority = urlsplit(candidate).netloc.rsplit("@", 1)[-1]
    except ValueError:
        return ""
    return authority.lower()


def read_auth_entry(data, address):
    auths = data.get("auths", {})
    if not isinstance(auths, dict):
        return None
    for key, entry in auths.items():
        if registry_address(key) != address or not isinstance(entry, dict):
            continue
        encoded = entry.get("auth")
        if not isinstance(encoded, str) or not encoded:
            continue
        try:
            username, separator, secret = (
                base64.b64decode(encoded).decode().partition(":")
            )
        except (ValueError, UnicodeDecodeError):
            continue
        if separator and username and secret:
            return username, secret
    return None


def credential_helper(data, address):
    helpers = data.get("credHelpers", {})
    if isinstance(helpers, dict):
        for key, helper in helpers.items():
            if registry_address(key) == address and isinstance(helper, str) and helper:
                return helper
    store = data.get("credsStore")
    return store if isinstance(store, str) and store else None


def read_helper(helper, address):
    for suffix in ("", ".exe"):
        try:
            result = subprocess.run(
                ["docker-credential-" + helper + suffix, "get"],
                input=address,
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
            credentials = json.loads(result.stdout) if result.returncode == 0 else {}
        except (OSError, subprocess.TimeoutExpired, ValueError):
            continue
        if not isinstance(credentials, dict):
            continue
        username = credentials.get("Username")
        secret = credentials.get("Secret")
        if username and secret:
            return username, secret
    return None


def docker_config_auth(config_path, registry):
    try:
        with open(config_path, encoding="utf-8") as config_file:
            data = json.load(config_file)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None

    address = registry_address(registry)
    if not address:
        return None

    credentials = read_auth_entry(data, address)
    if credentials:
        return credentials

    helper = credential_helper(data, address)
    return read_helper(helper, address) if helper else None


def main(argv):
    if len(argv) != 3:
        return 2
    credentials = docker_config_auth(argv[1], argv[2])
    if not credentials:
        return 1
    print(credentials[0])
    print(credentials[1])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
