#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=term.sh
. "$SCRIPT_DIR/term.sh"
TLS_DIR="$SCRIPT_DIR/../compose/config/tls"
umask 077
install -d -m 700 "$TLS_DIR"
TLS_DIR="$(cd "$TLS_DIR" && pwd)"

CRT="$TLS_DIR/server.crt"
KEY="$TLS_DIR/server.key"

HOSTNAME_ARG="${1:-}"
HOSTNAME_FQDN="$(hostname -f 2>/dev/null || hostname)"
CERT_HOST="${HOSTNAME_ARG:-$HOSTNAME_FQDN}"

if [[ "$CERT_HOST" =~ [/\\] ]]; then
  printf "${RED}%s${RESET} Invalid hostname: %s\n" "$SYM_ERR" "$CERT_HOST" >&2
  exit 1
fi

if [[ ! -w "$TLS_DIR" ]]; then
  printf "${RED}%s${RESET} Directory not writable: %s\n" "$SYM_ERR" "$TLS_DIR" >&2
  printf '  Fix: sudo chown %s:%s "%s" && chmod 700 "%s"\n' \
    "$(id -u)" "$(id -g)" "$TLS_DIR" "$TLS_DIR" >&2
  exit 1
fi

if [[ ! -f "$CRT" || ! -f "$KEY" ]]; then
  openssl req -x509 -nodes -newkey rsa:2048 -days 180 \
    -keyout "$KEY" -out "$CRT" \
    -subj "/CN=$CERT_HOST" \
    -addext "subjectAltName=DNS:$CERT_HOST,DNS:localhost,IP:127.0.0.1"
  chmod 600 "$CRT" "$KEY"
  printf "${GREEN}%s${RESET} Self-signed certificate generated.\n" "$SYM_OK"
  printf "  ${BOLD}CN:${RESET}   %s\n"                    "$CERT_HOST"
  printf "  ${BOLD}SANs:${RESET} %s, localhost, 127.0.0.1\n" "$CERT_HOST"
  printf "  ${BOLD}CRT:${RESET}  %s\n"                    "$CRT"
  printf "  ${BOLD}KEY:${RESET}  %s\n"                    "$KEY"
else
  printf "${CYAN}%s${RESET} TLS files already exist, skipping generation.\n" "$SYM_OK"
  printf "  ${BOLD}CRT:${RESET} %s\n" "$CRT"
  printf "  ${BOLD}KEY:${RESET} %s\n" "$KEY"
fi
