#!/usr/bin/env bash
# term.sh — shared terminal capability detection and logging helpers
# Usage: . "$(dirname "${BASH_SOURCE[0]}")/term.sh"
#
# Provides after sourcing:
#   Colors  : RED  YELLOW  GREEN  CYAN  BOLD  RESET  (empty strings when unsupported)
#   Symbols : SYM_OK  SYM_ERR  SYM_WARN  SYM_DASH
#   TTY     : _TTY_IN (read input)  _TTY_OUT (write prompts)  _TTY (alias for _TTY_IN)
#             _IS_INTERACTIVE (true/false)  require_tty <label>
#   Helpers : info  success  warn  err  header

# Guard: must be sourced, not executed directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  printf 'Error: term.sh must be sourced, not executed directly.\n' >&2
  printf 'Usage: . "%s"\n' "${BASH_SOURCE[0]}" >&2
  exit 1
fi

# ---------------------------------------------------------------------------
# Color support: disabled when stdout OR stderr is not a tty, TERM=dumb,
# NO_COLOR is set, or tput is missing.  We check both streams because
# info/success/header write to stdout while warn/err write to stderr.
# ---------------------------------------------------------------------------
_has_color() {
  [[ -t 1 ]] \
    && [[ -t 2 ]] \
    && [[ "${TERM:-}" != "dumb" ]] \
    && [[ -z "${NO_COLOR:-}" ]] \
    && command -v tput >/dev/null 2>&1 \
    && tput colors >/dev/null 2>&1 \
    && [[ $(tput colors 2>/dev/null || echo 0) -ge 8 ]]
}

if _has_color; then
  RED='\033[0;31m'
  YELLOW='\033[1;33m'
  GREEN='\033[0;32m'
  CYAN='\033[0;36m'
  BOLD='\033[1m'
  RESET='\033[0m'
else
  RED='' YELLOW='' GREEN='' CYAN='' BOLD='' RESET=''
fi

# ---------------------------------------------------------------------------
# Unicode support: fall back to ASCII on non-UTF-8 locales
# ---------------------------------------------------------------------------
_has_utf8() {
  local charmap
  charmap=$(locale charmap 2>/dev/null || true)
  [[ "$charmap" == "UTF-8" ]] \
    || [[ "${LANG:-}"     == *UTF-8* ]] \
    || [[ "${LC_ALL:-}"   == *UTF-8* ]] \
    || [[ "${LC_CTYPE:-}" == *UTF-8* ]]
}

if _has_utf8; then
  SYM_OK='✔'
  SYM_ERR='✖'
  SYM_WARN='⚠'
  SYM_DASH='──'
else
  SYM_OK='OK'
  SYM_ERR='!!'
  SYM_WARN='[!]'
  SYM_DASH='--'
fi

# ---------------------------------------------------------------------------
# TTY handling: separate input and output for interactive prompts.
#   _TTY_IN  — where to read user input from  (/dev/tty or /dev/stdin)
#   _TTY_OUT — where to write prompts to      (/dev/tty or stderr)
#   _TTY     — kept for backward-compat reads (same as _TTY_IN)
#   _IS_INTERACTIVE — true when a real TTY is available
# ---------------------------------------------------------------------------
if [[ -e /dev/tty ]] && [[ -r /dev/tty ]] && [[ -w /dev/tty ]]; then
  _TTY_IN=/dev/tty
  _TTY_OUT=/dev/tty
  _IS_INTERACTIVE=true
else
  _TTY_IN=/dev/stdin
  _TTY_OUT=/dev/stderr   # stderr is always writable; /dev/stdin is not
  _IS_INTERACTIVE=false
fi
_TTY="$_TTY_IN"  # backward compat

# Fail fast if a command requires interactive input but no TTY is available.
# Usage: require_tty "config wizard"
require_tty() {
  if [[ "$_IS_INTERACTIVE" == false ]]; then
    err "No interactive terminal available — cannot run $1."
    err "Ensure /dev/tty is accessible or provide configuration via environment variables."
    exit 1
  fi
}

# ---------------------------------------------------------------------------
# Logging helpers  (use printf, not echo -e, for portability)
# ---------------------------------------------------------------------------
info()    { printf "${CYAN}${BOLD}==>${RESET} %s\n"  "$*"; }
success() { printf "${GREEN}%s${RESET}  %s\n"  "$SYM_OK"   "$*"; }
warn()    { printf "${YELLOW}%s${RESET}  %s\n" "$SYM_WARN" "$*" >&2; }
err()     { printf "${RED}%s${RESET}  %s\n"    "$SYM_ERR"  "$*" >&2; }
header()  { printf "\n${BOLD}${CYAN}%s %s %s${RESET}\n" "$SYM_DASH" "$*" "$SYM_DASH"; }
