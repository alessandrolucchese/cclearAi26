#!/usr/bin/env bash
# skills-pack.sh — install Agent Skill packs into compose/config/skills/
# from Artifactory (online) or a local .zip (--file, offline).
#
# Usage:
#   skills-pack.sh <config-dir> install [pack] [--version <v>] [--file <zip>]
#                                       [--url <base-url>] [--force]
#   skills-pack.sh <config-dir> download [pack] [--version <v>] [--url <base-url>] [--force]
#   skills-pack.sh <config-dir> list
#   skills-pack.sh <config-dir> remove <pack>
#
# Auth reuses `docker login` credentials. SKILLS_REPO_URL overrides the repo.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=term.sh
. "$SCRIPT_DIR/term.sh"
# shellcheck source=docker_config_auth.sh
. "$SCRIPT_DIR/docker_config_auth.sh"

DEFAULT_REPO_URL="https://cpacket.jfrog.io/artifactory/ai-workflows-knowledge"
DEFAULT_PACK="cclear-core"

usage() {
  printf "${BOLD}Usage:${RESET} ./cclear-mcp.sh skills <command>\n\n"
  printf "${BOLD}Commands:${RESET}\n"
  printf "  ${CYAN}%s${RESET}\n" "install [pack] [--version <v>] [--file <zip>] [--url <base-url>] [--force]"
  printf "      Install a skill pack (default pack: %s, default version: latest).\n" "$DEFAULT_PACK"
  printf "      --file installs from a local .zip (offline mode, no download).\n"
  printf "      Only one pack can be installed at a time; --force replaces it.\n"
  printf "  ${CYAN}%s${RESET}\n" "download [pack] [--version <v>] [--url <base-url>] [--force]"
  printf "      Download a pack zip without installing (for offline transfer).\n"
  printf "  ${CYAN}%s${RESET}\n" "list"
  printf "      Show the installed pack and skills.\n"
  printf "  ${CYAN}%s${RESET}\n" "remove [pack]"
  printf "      Remove the installed pack (name optional).\n"
}

CONFIG_DIR="${1:-}"
if [[ -z "$CONFIG_DIR" || ! -d "$CONFIG_DIR" ]]; then
  err "Config directory not found: ${CONFIG_DIR:-<missing>}"
  usage
  exit 1
fi
shift

SKILLS_DIR="$CONFIG_DIR/skills"
PACKS_DIR="$SKILLS_DIR/.packs"
DOWNLOADS_DIR="$CONFIG_DIR/skills-downloads"

cmd="${1:-}"
shift || true

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
TMP_DIR=""
cleanup() {
  if [[ -n "$TMP_DIR" ]]; then
    rm -rf "$TMP_DIR"
  fi
}
trap cleanup EXIT

AUTH_USER=""
AUTH_TOKEN=""

REPO_HOST=""

# Set REPO_HOST and AUTH_USER/AUTH_TOKEN from docker login credentials.
resolve_credentials() {
  local url="$1"
  REPO_HOST="${url#*://}"
  REPO_HOST="${REPO_HOST%%/*}"
  REPO_HOST="${REPO_HOST##*@}"
  REPO_HOST=$(printf '%s' "$REPO_HOST" | tr '[:upper:]' '[:lower:]')
  local creds
  if creds=$(_docker_config_auth "$REPO_HOST"); then
    AUTH_USER=$(printf '%s\n' "$creds" | sed -n 1p)
    AUTH_TOKEN=$(printf '%s\n' "$creds" | sed -n 2p)
    info "Using docker login credentials for ${REPO_HOST}"
  fi
}

# No credential prompt — point the user at docker login.
auth_hint() {
  local code="$1"
  err "Authentication required (HTTP $code)."
  err "Log in first with: docker login ${REPO_HOST:-cpacket.jfrog.io}"
}

# Fetch URL to file; echoes the HTTP status. Creds go to curl via stdin
# so the token never appears in the process list. Pass "progress" as $3
# to show a progress bar on interactive terminals.
_fetch() {
  local out="$1" url="$2" progress="${3:-}" code
  local -a opts=(-L --retry 2 --connect-timeout 10 --max-time 300)
  local errout=/dev/null
  if [[ "$progress" == "progress" && -t 2 ]]; then
    opts+=(-S --progress-bar)
    errout=/dev/stderr
  else
    opts+=(-sS)
  fi
  if [[ -n "$AUTH_USER" && -n "$AUTH_TOKEN" ]]; then
    code=$(printf 'user = "%s:%s"\n' "$AUTH_USER" "$AUTH_TOKEN" \
      | curl "${opts[@]}" -K - -o "$out" -w '%{http_code}' "$url" 2>"$errout") || code="000"
  else
    code=$(curl "${opts[@]}" -o "$out" -w '%{http_code}' "$url" 2>"$errout") || code="000"
  fi
  printf '%s' "$code"
}


# Convert a repo URL into its storage-API form (used to list versions).
_storage_api_url() {
  local base="$1"
  case "$base" in
    */artifactory/*) printf '%s/artifactory/api/storage/%s' "${base%%/artifactory/*}" "${base#*/artifactory/}" ;;
    *) return 1 ;;
  esac
}

# Newest version of a pack, from the repo folder listing.
resolve_latest_version() {
  local base="$1" pack="$2" api_url listing
  if ! api_url=$(_storage_api_url "$base"); then
    err "Cannot resolve 'latest' for repo URL: $base"
    err "Pass an explicit version with --version <v>."
    return 1
  fi
  local out="$TMP_DIR/versions.json" code
  code=$(_fetch "$out" "$api_url/packs/$pack")
  if [[ "$code" == "401" || "$code" == "403" ]]; then
    auth_hint "$code"
    return 1
  fi
  if [[ "$code" != "200" ]]; then
    err "Failed to list versions for pack '$pack' (HTTP $code): $api_url/packs/$pack"
    err "Pass an explicit version with --version <v>."
    return 1
  fi
  listing=$(grep -oE '"uri"[[:space:]]*:[[:space:]]*"/[^"]+"' "$out" \
    | sed -E 's#.*"/([^"]+)"#\1#' || true)
  if [[ -z "$listing" ]]; then
    err "No versions found for pack '$pack' at $api_url/packs/$pack"
    return 1
  fi
  if printf '1\n' | sort -V >/dev/null 2>&1; then
    printf '%s\n' "$listing" | sort -V | tail -n1
  else
    printf '%s\n' "$listing" | sort | tail -n1
  fi
}

# sha256 of a local file ("" when no tool is available).
local_sha256() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  fi
}

# Expected sha256 of a repo file, from the storage API ("" when unavailable).
remote_sha256() {
  local base="$1" path="$2" api_url out code
  api_url=$(_storage_api_url "$base") || return 0
  out="$TMP_DIR/stat.json"
  code=$(_fetch "$out" "$api_url/$path")
  [[ "$code" == "200" ]] || return 0
  grep -Eo '"sha256"[[:space:]]*:[[:space:]]*"[a-f0-9]{64}"' "$out" \
    | head -n1 | grep -Eo '[a-f0-9]{64}' || true
}

# Verify a downloaded pack against the repo checksum; fails on mismatch.
verify_download() {
  local file="$1" base="$2" path="$3" expected actual
  expected=$(remote_sha256 "$base" "$path")
  if [[ -z "$expected" ]]; then
    warn "Checksum not available from the repository — skipping verification"
    return 0
  fi
  actual=$(local_sha256 "$file")
  if [[ -z "$actual" ]]; then
    warn "No sha256 tool available — skipping verification"
    return 0
  fi
  if [[ "$actual" != "$expected" ]]; then
    err "Checksum mismatch for $(basename "$path")"
    err "  expected: $expected"
    err "  got:      $actual"
    return 1
  fi
  success "Checksum verified (sha256)"
}

# Download a pack zip to $4 and verify its checksum.
download_pack() {
  local pack="$1" version="$2" base_url="$3" out="$4"
  local pack_path="packs/$pack/$version/$pack-$version.zip"
  local url="$base_url/$pack_path" code
  info "Downloading $url"
  code=$(_fetch "$out" "$url" progress)
  case "$code" in
    200) verify_download "$out" "$base_url" "$pack_path" ;;
    401|403)
      auth_hint "$code"
      return 1 ;;
    404)
      err "Skill pack not found (HTTP 404): $url"
      err "Check the pack name and version."
      return 1 ;;
    *)
      err "Download failed (HTTP ${code:-000}): $url"
      return 1 ;;
  esac
}

# Reject entries that would escape the extract dir (zip slip).
validate_zip() {
  local zip="$1" names
  if command -v python3 >/dev/null 2>&1; then
    names=$(python3 -c 'import sys, zipfile; print("\n".join(zipfile.ZipFile(sys.argv[1]).namelist()))' "$zip" 2>/dev/null)
  elif command -v unzip >/dev/null 2>&1; then
    names=$(unzip -Z1 "$zip" 2>/dev/null)
  else
    return 0
  fi

  if [[ -z "$names" ]] || printf '%s\n' "$names" | grep -Eq '^/|(^|/)\.\.(/|$)|[\]'; then
    err "Invalid pack archive: contains unsafe paths."
    return 1
  fi
}

extract_zip() {
  local zip="$1" dest="$2"
  validate_zip "$zip" || return 1
  if command -v unzip >/dev/null 2>&1; then
    unzip -q "$zip" -d "$dest"
  elif command -v python3 >/dev/null 2>&1; then
    python3 -m zipfile -e "$zip" "$dest"
  else
    err "Neither 'unzip' nor 'python3' is available to extract the pack."
    return 1
  fi
  # unzip can restore symlinks, which could expose host files through the
  # read-only bind mount — allow regular files and directories only.
  if [[ -n "$(find "$dest" ! -type f ! -type d 2>/dev/null | head -n1)" ]]; then
    err "Invalid pack archive: contains symlinks or special files."
    return 1
  fi
}

# Skill dirs (containing SKILL.md) inside an extracted pack, any layout.
find_skill_dirs() {
  local root="$1"
  find "$root" -maxdepth 4 -mindepth 2 -name SKILL.md -type f 2>/dev/null \
    | while IFS= read -r f; do dirname "$f"; done | sort -u
}

manifest_file() { printf '%s' "$PACKS_DIR/$1.manifest"; }

manifest_get() {
  local file="$1" key="$2"
  [[ -f "$file" ]] || return 0
  grep -m1 "^${key}=" "$file" | cut -d= -f2- || true
}

# Installed pack names, one per line.
installed_packs() {
  local mf
  for mf in "$PACKS_DIR"/*.manifest; do
    [[ -f "$mf" ]] || continue
    basename "$mf" .manifest
  done
}

# Delete a pack's skills and manifest.
remove_pack() {
  local mf name
  mf="$(manifest_file "$1")"
  for name in $(manifest_get "$mf" skills); do
    rm -rf "${SKILLS_DIR:?}/$name"
  done
  rm -f "$mf"
}

# Only one pack may be installed — fail when another pack is present
# unless --force (the install then replaces it).
ensure_single_pack() {
  local pack="$1" force="$2" others
  others=$(installed_packs | grep -Fxv "$pack" || true)
  [[ -z "$others" ]] && return 0
  if [[ "$force" == true ]]; then
    warn "Replacing installed pack(s): ${others//$'\n'/ } (only one pack at a time)"
  else
    err "Pack '$(printf '%s' "$others" | head -n1)' is already installed — only one pack can be installed at a time."
    err "Replace it with --force, or remove it first: ./cclear-mcp.sh skills remove <pack>"
    exit 1
  fi
}

# True when at least one skill is installed.
has_installed_skills() {
  local f
  for f in "$SKILLS_DIR"/*/SKILL.md; do
    [[ -f "$f" ]] && return 0
  done
  return 1
}

# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------
cmd_install() {
  local pack="" version="" zip_file="" base_url="${SKILLS_REPO_URL:-$DEFAULT_REPO_URL}" force=false

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --version) version="${2:-}"; shift 2 ;;
      --file)    zip_file="${2:-}"; shift 2 ;;
      --url)     base_url="${2:-}"; shift 2 ;;
      --force)   force=true; shift ;;
      -h|--help) usage; exit 0 ;;
      -*)        err "Unknown option: $1"; usage; exit 1 ;;
      *)
        if [[ -n "$pack" ]]; then
          err "Unexpected argument: $1"; usage; exit 1
        fi
        pack="$1"; shift ;;
    esac
  done

  base_url="${base_url%/}"
  TMP_DIR="$(mktemp -d)"
  mkdir -p "$SKILLS_DIR"

  # ---- Acquire the pack zip (offline --file, or download) ----
  if [[ -n "$zip_file" ]]; then
    if [[ ! -f "$zip_file" ]]; then
      err "Skill pack file not found: $zip_file"
      exit 1
    fi
    # Derive pack/version from the filename (<pack>-<version>.zip) if not given.
    local fname
    fname="$(basename "$zip_file" .zip)"
    if [[ -z "$pack" ]]; then
      if [[ "$fname" =~ ^(.+)-([0-9][0-9A-Za-z.+-]*)$ ]]; then
        pack="${BASH_REMATCH[1]}"
        version="${version:-${BASH_REMATCH[2]}}"
      else
        pack="$fname"
      fi
    fi
    version="${version:-unknown}"
    ensure_single_pack "$pack" "$force"
    if [[ "$version" == "unknown" ]]; then
      info "Installing skill pack '${pack}' from local file (offline)"
    else
      info "Installing skill pack '${pack}' ${version} from local file (offline)"
    fi
    cp "$zip_file" "$TMP_DIR/pack.zip"
  else
    pack="${pack:-$DEFAULT_PACK}"
    ensure_single_pack "$pack" "$force"
    resolve_credentials "$base_url"
    if [[ -z "$version" || "$version" == "latest" ]]; then
      info "Resolving latest version of '${pack}'..."
      version=$(resolve_latest_version "$base_url" "$pack")
      info "Latest version: $version"
    fi

    local current
    current=$(manifest_get "$(manifest_file "$pack")" version)
    if [[ -n "$current" && "$current" == "$version" && "$force" == false ]]; then
      success "Skill pack '${pack}' ${version} is already installed (use --force to reinstall)"
      return 0
    fi

    download_pack "$pack" "$version" "$base_url" "$TMP_DIR/pack.zip" || exit 1
  fi

  # ---- Extract and locate skills ----
  local extract_dir="$TMP_DIR/extract"
  mkdir -p "$extract_dir"
  extract_zip "$TMP_DIR/pack.zip" "$extract_dir"

  # version.txt inside the pack is authoritative when present.
  local vfile pack_version
  vfile=$(find "$extract_dir" -maxdepth 2 -name version.txt -type f 2>/dev/null | head -n1)
  if [[ -n "$vfile" ]]; then
    pack_version=$(head -n1 "$vfile" | tr -d '[:space:]')
    if [[ -n "$pack_version" ]]; then
      if [[ "$version" != "unknown" && "$version" != "$pack_version" ]]; then
        warn "Pack reports version ${pack_version} (expected ${version})"
      fi
      version="$pack_version"
    fi
  fi

  local skill_dirs
  skill_dirs=$(find_skill_dirs "$extract_dir")
  if [[ -z "$skill_dirs" ]]; then
    err "No skills (directories containing SKILL.md) found in the pack archive."
    exit 1
  fi

  # ---- Remove any other pack (--force checked earlier), then this pack's old install ----
  local p name dir
  for p in $(installed_packs); do
    [[ "$p" == "$pack" ]] && continue
    info "Removing installed pack '${p}'..."
    remove_pack "$p"
  done

  local old_skills
  old_skills=$(manifest_get "$(manifest_file "$pack")" skills)
  if [[ -n "$old_skills" ]]; then
    info "Removing previous install of '${pack}'..."
    for name in $old_skills; do
      rm -rf "${SKILLS_DIR:?}/$name"
    done
  fi

  local installed=()
  while IFS= read -r dir; do
    name="$(basename "$dir")"
    rm -rf "${SKILLS_DIR:?}/$name"
    cp -R "$dir" "$SKILLS_DIR/$name"
    # The container reads /skills as uid 1001 — a restrictive umask (e.g. the
    # config wizard's 077) must not make skills unreadable.
    chmod -R a+rX "$SKILLS_DIR/$name"
    installed+=("$name")
  done <<< "$skill_dirs"

  mkdir -p "$PACKS_DIR"
  {
    printf 'pack=%s\n' "$pack"
    printf 'version=%s\n' "$version"
    printf 'installed_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf 'skills=%s\n' "${installed[*]}"
  } > "$(manifest_file "$pack")"

  local noun="skills" vlabel=" ${version}"
  [[ ${#installed[@]} -eq 1 ]] && noun="skill"
  [[ "$version" == "unknown" ]] && vlabel=""
  success "Installed skill pack '${pack}'${vlabel} (${#installed[@]} ${noun}) into $SKILLS_DIR"
  for name in "${installed[@]}"; do
    printf "    ${CYAN}%s${RESET} %s\n" "•" "$name"
  done
}

# ---------------------------------------------------------------------------
# download (keep the zip for offline transfer, no install)
# ---------------------------------------------------------------------------
cmd_download() {
  local pack="" version="" base_url="${SKILLS_REPO_URL:-$DEFAULT_REPO_URL}" force=false

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --version) version="${2:-}"; shift 2 ;;
      --url)     base_url="${2:-}"; shift 2 ;;
      --force)   force=true; shift ;;
      -h|--help) usage; exit 0 ;;
      -*)        err "Unknown option: $1"; usage; exit 1 ;;
      *)
        if [[ -n "$pack" ]]; then
          err "Unexpected argument: $1"; usage; exit 1
        fi
        pack="$1"; shift ;;
    esac
  done

  pack="${pack:-$DEFAULT_PACK}"
  base_url="${base_url%/}"
  TMP_DIR="$(mktemp -d)"

  resolve_credentials "$base_url"
  if [[ -z "$version" || "$version" == "latest" ]]; then
    info "Resolving latest version of '${pack}'..."
    version=$(resolve_latest_version "$base_url" "$pack")
    info "Latest version: $version"
  fi

  mkdir -p "$DOWNLOADS_DIR"
  local out="$DOWNLOADS_DIR/$pack-$version.zip"
  if [[ -f "$out" && "$force" == false ]]; then
    success "Already downloaded (use --force to re-download):"
    printf "    %s\n" "$out"
    return 0
  fi

  download_pack "$pack" "$version" "$base_url" "$TMP_DIR/pack.zip" || exit 1
  mv "$TMP_DIR/pack.zip" "$out"

  success "Downloaded skill pack '${pack}' ${version}:"
  printf "    %s\n" "$out"
  info "Install offline with: ./cclear-mcp.sh skills install --file $out"
}

# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------
cmd_list() {
  header "Installed Skill Packs"
  local found=false mf pack version skills count
  for mf in "$PACKS_DIR"/*.manifest; do
    [[ -f "$mf" ]] || continue
    found=true
    pack="$(manifest_get "$mf" pack)"
    version="$(manifest_get "$mf" version)"
    skills="$(manifest_get "$mf" skills)"
    count=$(printf '%s' "$skills" | wc -w | tr -d '[:space:]')
    local noun="skills"
    [[ "$count" -eq 1 ]] && noun="skill"
    [[ "$version" == "unknown" ]] && version="-"
    printf "  ${BOLD}%s${RESET}  %s  (%s %s)\n" "${pack:-$(basename "$mf" .manifest)}" "$version" "$count" "$noun"
    local s
    for s in $skills; do
      printf "    ${CYAN}%s${RESET} %s\n" "•" "$s"
    done
  done

  # Skills on disk that no manifest tracks.
  local unmanaged=() d name
  if [[ -d "$SKILLS_DIR" ]]; then
    for d in "$SKILLS_DIR"/*/; do
      [[ -f "${d}SKILL.md" ]] || continue
      name="$(basename "$d")"
      local owned=false
      for mf in "$PACKS_DIR"/*.manifest; do
        [[ -f "$mf" ]] || continue
        if printf ' %s ' "$(manifest_get "$mf" skills)" | grep -q " $name "; then
          owned=true
          break
        fi
      done
      [[ "$owned" == false ]] && unmanaged+=("$name")
    done
  fi
  if [[ ${#unmanaged[@]} -gt 0 ]]; then
    found=true
    printf "  ${BOLD}%s${RESET}\n" "(unmanaged — added manually)"
    for name in "${unmanaged[@]}"; do
      printf "    ${CYAN}%s${RESET} %s\n" "•" "$name"
    done
  fi

  if [[ "$found" == false ]]; then
    printf "  No skills installed in %s\n" "$SKILLS_DIR"
    printf "  Install with: ${BOLD}./cclear-mcp.sh skills install${RESET}\n"
  fi
}

# ---------------------------------------------------------------------------
# remove
# ---------------------------------------------------------------------------
cmd_remove() {
  local pack="${1:-}"
  if [[ -z "$pack" ]]; then
    # Only one pack can be installed — default to it.
    local count
    count=$(installed_packs | wc -l | tr -d '[:space:]')
    if [[ "$count" -eq 0 ]]; then
      err "No skill pack is installed."
      exit 1
    elif [[ "$count" -gt 1 ]]; then
      err "Multiple packs are installed ($(installed_packs | paste -sd' ' -)) — specify which to remove."
      exit 1
    fi
    pack=$(installed_packs)
  fi
  if [[ ! -f "$(manifest_file "$pack")" ]]; then
    err "Skill pack '$pack' is not installed"
    exit 1
  fi
  remove_pack "$pack"
  success "Removed skill pack '${pack}'"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
case "$cmd" in
  install)  cmd_install "$@" ;;
  download) cmd_download "$@" ;;
  list)     cmd_list ;;
  remove)   cmd_remove "$@" ;;
  # Internal probe for cclear-mcp.sh and the wizard.
  has-skills) has_installed_skills ;;
  -h|--help|help|"") usage ;;
  *)
    err "Unknown command: $cmd"
    usage
    exit 1
    ;;
esac
