#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=term.sh
. "$SCRIPT_DIR/term.sh"

# ---------------------------------------------------------------------------
# Args
# ---------------------------------------------------------------------------
CONFIG_DIR="${1:-}"
RECONFIGURE="${2:-}"   # pass --reconfigure to force prompts

if [[ -z "$CONFIG_DIR" ]]; then
  err "Usage: $0 <config-dir> [--reconfigure]"
  exit 1
fi

umask 077
mkdir -p "$CONFIG_DIR"

VAULT_ENV_FILE="$CONFIG_DIR/vault.env"
MCP_PROXY_FILE="$CONFIG_DIR/mcp-proxy-settings.yaml"
MCP_PROXY_EXAMPLE="$CONFIG_DIR/examples/mcp-proxy-settings.example.yaml"
MCP_PROXY_SKILLS_EXAMPLE="$CONFIG_DIR/examples/mcp-proxy-settings.skills.example.yaml"
INSTANCES_FILE="$CONFIG_DIR/cclear-instances.yaml"
INSTANCES_EXAMPLE="$CONFIG_DIR/examples/cclear-instances.example.yaml"
DEPLOYMENT_ENV_FILE="$CONFIG_DIR/deployment.env"

# True during the full wizard; drives the "Step N/3" headers.
_FULL_WIZARD=false

# ---------------------------------------------------------------------------
# Prompt helpers
# ---------------------------------------------------------------------------
prompt_value() {
  local prompt="$1"
  local default="$2"
  local value
  printf "${BOLD}%s${RESET} [%s]: " "$prompt" "$default" >"$_TTY_OUT"
  read -r value <"$_TTY_IN"
  printf '%s' "${value:-$default}"
}

prompt_secret() {
  local prompt="$1"
  local value=""
  while [[ -z "$value" ]]; do
    printf "${BOLD}%s${RESET}: " "$prompt" >"$_TTY_OUT"
    if read -rs value <"$_TTY_IN" 2>/dev/null; then
      printf '\n' >"$_TTY_OUT"
    else
      read -r value <"$_TTY_IN"
      printf '\n' >"$_TTY_OUT"
    fi
    if [[ -z "$value" ]]; then
      warn "This field is required."
    fi
  done
  printf '%s' "$value"
}

prompt_port_default() {
  local default="${1:-443}"
  local value
  while true; do
    value=$(prompt_value "cClear port" "$default")
    if [[ "$value" =~ ^[0-9]+$ ]] && (( value >= 1 && value <= 65535 )); then
      printf '%s' "$value"
      return
    fi
    warn "Port must be a number between 1 and 65535."
  done
}

prompt_yn() {
  local prompt="$1"
  local default="${2:-N}"
  local value
  local display
  if [[ "$default" =~ ^[Yy]$ ]]; then display="Y/n"; else display="y/N"; fi
  while true; do
    printf "${BOLD}%s${RESET} [%s]: " "$prompt" "$display" >"$_TTY_OUT"
    read -r value <"$_TTY_IN"
    value="${value:-$default}"
    case "$value" in
      [Yy]*) return 0 ;;
      [Nn]*) return 1 ;;
      *)     warn "Please enter y or n." ;;
    esac
  done
}

# Render an action menu and read a single-letter choice. The FIRST option is
# the default (selected when the user just presses Enter). Echoes the chosen
# letter in uppercase, e.g. "K".
#   action=$(prompt_action K Keep E Edit R Remove)
prompt_action() {
  local -a keys=() labels=()
  while (( $# >= 2 )); do
    keys+=("$(printf '%s' "$1" | tr '[:lower:]' '[:upper:]')")
    labels+=("$2")
    shift 2
  done
  local default="${keys[0]}" default_label="${labels[0]}"

  local menu="" sep="" i
  for ((i = 0; i < ${#keys[@]}; i++)); do
    menu+="${sep}[${CYAN}${keys[$i]}${RESET}] ${labels[$i]}"
    sep="   "
  done
  # %b (not %s) so the embedded ${CYAN}/${RESET} escape codes in $menu render.
  printf "  %b   ${CYAN}(Enter = %s)${RESET}\n" "$menu" "$default_label" >"$_TTY_OUT"

  local valid=" ${keys[*]} " reply
  while true; do
    printf "  ${BOLD}▸${RESET} " >"$_TTY_OUT"
    read -r reply <"$_TTY_IN"
    reply="${reply:-$default}"
    reply=$(printf '%s' "$reply" | tr '[:lower:]' '[:upper:]')
    if [[ "$valid" == *" $reply "* ]]; then
      printf '%s' "$reply"
      return 0
    fi
    warn "Please enter one of: ${keys[*]}"
  done
}

# Section header with progress, e.g. "── Step 1/3 · cClear Instances ──".
step_header() {
  local num="$1" total="$2"
  shift 2
  printf "\n${BOLD}${CYAN}%s Step %s/%s · %s %s${RESET}\n" \
    "$SYM_DASH" "$num" "$total" "$*" "$SYM_DASH"
}

# Use a numbered step header during the full wizard; a plain header otherwise.
section_header() {
  local step="$1"
  shift
  if [[ "$_FULL_WIZARD" == true ]]; then
    step_header "$step" 2 "$*"
  else
    header "$*"
  fi
}

# Up-front map of the wizard so the user knows what to expect.
print_wizard_roadmap() {
  printf "\n  ${BOLD}This wizard has 2 main steps:${RESET}\n"
  printf "    ${CYAN}1${RESET}  cClear instances   Connection details (host, port, login)\n"
  printf "    ${CYAN}2${RESET}  Deployment mode    gateway (recommended) on/off, optional Agent Skills container\n"
  printf "\n  ${CYAN}Tip:${RESET} press Enter to accept the default shown in each prompt.\n"
}

pick_auth_mode() {
  local current="${1:-}"
  local result REPLY default_choice="1"
  [[ "$current" == "env" ]] && default_choice="2"
  printf '\n' >"$_TTY_OUT"
  printf "${BOLD}Password auth mode:${RESET}\n" >"$_TTY_OUT"
  printf "  ${CYAN}[1]${RESET} docker-secret  ${GREEN}(recommended)${RESET} — password in tmpfs, never in plain text\n" >"$_TTY_OUT"
  printf "  ${CYAN}[2]${RESET} env            — password stored in plain text in the YAML config\n" >"$_TTY_OUT"
  while true; do
    printf "${BOLD}Choice${RESET} [%s]: " "$default_choice" >"$_TTY_OUT"
    read -r REPLY <"$_TTY_IN"
    REPLY="${REPLY:-$default_choice}"
    case "$REPLY" in
      1) result="docker-secret"; break ;;
      2) result="env";           break ;;
      *) warn "Enter 1 or 2." ;;
    esac
  done
  printf '%s' "$result"
}

confirm_write() {
  local file="$1"
  printf '\n'
  if [[ -f "$file" ]]; then
    warn "This will overwrite: $file"
    prompt_yn "Continue?" "Y" || return 1
  fi
  return 0
}

prompt_instance_name() {
  local default="$1"
  local value
  while true; do
    value=$(prompt_value "Instance name (short, no spaces)" "$default")
    if [[ "$value" =~ ^[a-zA-Z0-9_-]+$ ]]; then
      printf '%s' "$value"
      return
    fi
    warn "Name must contain only letters, numbers, hyphens, and underscores."
  done
}

# ---------------------------------------------------------------------------
# Parse existing cclear-instances.yaml into arrays for use as defaults
# ---------------------------------------------------------------------------
_EX_NAMES=() _EX_HOSTS=() _EX_PORTS=() _EX_USERS=() _EX_AUTH=() _EX_PWFILES=() _EX_VPATHS=() _EX_VFIELDS=()

_load_existing_instances() {
  local file="$1"
  [[ -f "$file" ]] || return 0

  local cur_name="" cur_host="" cur_port="" cur_user="" cur_auth="" cur_pwfile="" cur_vpath="" cur_vfield=""

  while IFS= read -r line; do
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ -z "${line// /}" ]] && continue

    if [[ "$line" =~ ^[[:space:]]{2}([a-zA-Z0-9_-]+):[[:space:]]*$ ]]; then
      if [[ -n "$cur_name" ]]; then
        _EX_NAMES+=("$cur_name"); _EX_HOSTS+=("$cur_host"); _EX_PORTS+=("${cur_port:-443}")
        _EX_USERS+=("${cur_user:-cpacket}"); _EX_AUTH+=("${cur_auth:-docker-secret}")
        _EX_PWFILES+=("$cur_pwfile"); _EX_VPATHS+=("$cur_vpath"); _EX_VFIELDS+=("$cur_vfield")
      fi
      cur_name="${BASH_REMATCH[1]}"
      cur_host="" cur_port="" cur_user="" cur_auth="" cur_pwfile="" cur_vpath="" cur_vfield=""
      continue
    fi

    if [[ "$line" =~ ^[[:space:]]{4}([a-z_]+):[[:space:]]*(.+)$ ]]; then
      local key="${BASH_REMATCH[1]}" val="${BASH_REMATCH[2]}"
      case "$key" in
        host)              cur_host="$val" ;;
        port)              cur_port="$val" ;;
        username)          cur_user="$val" ;;
        auth_mode)         cur_auth="$val" ;;
        password_file)     cur_pwfile="$val" ;;
        vault_secret_path) cur_vpath="$val" ;;
        vault_secret_field) cur_vfield="$val" ;;
      esac
    fi
  done < "$file"

  if [[ -n "$cur_name" ]]; then
    _EX_NAMES+=("$cur_name"); _EX_HOSTS+=("$cur_host"); _EX_PORTS+=("${cur_port:-443}")
    _EX_USERS+=("${cur_user:-cpacket}"); _EX_AUTH+=("${cur_auth:-docker-secret}")
    _EX_PWFILES+=("$cur_pwfile"); _EX_VPATHS+=("$cur_vpath"); _EX_VFIELDS+=("$cur_vfield")
  fi
}

# ---------------------------------------------------------------------------
# cclear-instances.yaml — the sole connection config
# ---------------------------------------------------------------------------
create_instances_yaml() {
  section_header 1 "cClear Instances"
  require_tty "configuration wizard"

  # Load existing values as defaults for reconfigure
  _load_existing_instances "$INSTANCES_FILE"
  local num_existing=${#_EX_NAMES[@]}

  local yaml_content=""
  yaml_content+="cclear_instances:\n"
  local _has_vault=false
  local _has_changes=false
  local idx=0
  local add_more=true

  while [[ "$add_more" == true ]]; do
    header "cClear Instance #$((idx + 1))"

    local def_name="cclear-${idx}" def_host="cclear.example.com" def_port="443"
    local def_user="cpacket" def_auth="" def_pwfile="" def_vpath="" def_vfield=""
    if [[ $idx -lt $num_existing ]]; then
      def_name="${_EX_NAMES[$idx]}"
      def_host="${_EX_HOSTS[$idx]}"
      def_port="${_EX_PORTS[$idx]}"
      def_user="${_EX_USERS[$idx]}"
      def_auth="${_EX_AUTH[$idx]}"
      def_pwfile="${_EX_PWFILES[$idx]}"
      def_vpath="${_EX_VPATHS[$idx]}"
      def_vfield="${_EX_VFIELDS[$idx]}"

      # Show existing instance details
      printf "\n" >"$_TTY_OUT"
      printf "  ${BOLD}── Instance '${def_name}' ──${RESET}\n" >"$_TTY_OUT"
      printf "  ${BOLD}%-12s${RESET} %s\n" "Host"      "$def_host" >"$_TTY_OUT"
      printf "  ${BOLD}%-12s${RESET} %s\n" "Port"      "$def_port" >"$_TTY_OUT"
      printf "  ${BOLD}%-12s${RESET} %s\n" "Username"  "$def_user" >"$_TTY_OUT"
      printf "  ${BOLD}%-12s${RESET} %s\n" "Auth mode" "${def_auth:-docker-secret}" >"$_TTY_OUT"
      [[ -n "$def_vpath" ]] && \
        printf "  ${BOLD}%-12s${RESET} %s\n" "Vault path" "$def_vpath" >"$_TTY_OUT"
      printf "\n" >"$_TTY_OUT"

      # 3-way action prompt (Enter keeps the instance unchanged)
      local action=""
      case "$(prompt_action K Keep E Edit R Remove)" in
        K) action="keep" ;;
        E) action="edit" ;;
        R) action="remove" ;;
      esac

      if [[ "$action" == "keep" ]]; then
        # Re-emit existing config without prompting
        [[ $idx -gt 0 ]] && yaml_content+="\n"
        yaml_content+="  ${def_name}:\n"
        yaml_content+="    host: ${def_host}\n"
        yaml_content+="    port: ${def_port}\n"
        yaml_content+="    username: ${def_user}\n"
        yaml_content+="    ssl: true\n"
        yaml_content+="    verify_ssl: false\n"
        yaml_content+="    timeout: 600\n"
        yaml_content+="    auth_mode: ${def_auth:-docker-secret}\n"
        if [[ "${def_auth:-docker-secret}" == "env" ]]; then
          local existing_pw=""
          existing_pw=$(grep -A20 "^  ${def_name}:" "$INSTANCES_FILE" | grep "password:" | head -1 | sed 's/.*password: *//' || true)
          yaml_content+="    password: ${existing_pw}\n"
        else
          [[ -n "$def_pwfile" ]] && yaml_content+="    password_file: ${def_pwfile}\n"
          if [[ -n "$def_vpath" ]]; then
            yaml_content+="    vault_secret_path: ${def_vpath}\n"
            yaml_content+="    vault_secret_field: ${def_vfield:-value}\n"
            _has_vault=true
          fi
        fi
        idx=$((idx + 1))
        if [[ $idx -lt $num_existing ]]; then
          continue
        fi
        if ! prompt_yn "Add another cClear instance?" "N"; then
          add_more=false
        fi
        continue
      fi

      if [[ "$action" == "remove" ]]; then
        warn "Removed instance '${def_name}'"
        _has_changes=true
        idx=$((idx + 1))
        if [[ $idx -lt $num_existing ]]; then
          continue
        fi
        if ! prompt_yn "Add another cClear instance?" "N"; then
          add_more=false
        fi
        continue
      fi

      # action == "edit" — fall through to edit prompts below
    fi

    local name host port username auth_mode password use_vault_inst vpath vfield

    name=$(prompt_instance_name "$def_name")
    host=$(prompt_value "cClear host" "$def_host")
    port=$(prompt_port_default "$def_port")
    username=$(prompt_value "cClear username" "$def_user")
    auth_mode=$(pick_auth_mode "$def_auth")

    password=""
    use_vault_inst="N"
    vpath=""
    vfield=""

    if [[ "$auth_mode" == "docker-secret" ]]; then
      local vault_default="N"
      [[ -n "$def_vpath" ]] && vault_default="Y"
      if prompt_yn "Use Vault to inject the password for '${name}'?" "$vault_default"; then
        use_vault_inst="Y"
        _has_vault=true
        vpath=$(prompt_value "Vault secret path for '${name}'" "${def_vpath:-cclear/${name}/password}")
        vfield=$(prompt_value "Vault secret field" "${def_vfield:-value}")
      fi
    else
      password=$(prompt_secret "cClear password")
    fi

    printf '\n'
    info "Review instance '${name}':"
    printf "  ${BOLD}%-12s${RESET} %s\n" "Host"      "$host"
    printf "  ${BOLD}%-12s${RESET} %s\n" "Port"      "$port"
    printf "  ${BOLD}%-12s${RESET} %s\n" "Username"  "$username"
    printf "  ${BOLD}%-12s${RESET} %s\n" "Auth mode" "$auth_mode"
    if [[ "$auth_mode" == "env" ]]; then
      printf "  ${BOLD}%-12s${RESET} %s\n" "Password"  "(provided)"
    else
      printf "  ${BOLD}%-12s${RESET} %s\n" "Password"  "/secure/cclear-password-${idx} (tmpfs)"
      if [[ "$use_vault_inst" == "Y" ]]; then
        printf "  ${BOLD}%-12s${RESET} %s\n" "Vault path"  "$vpath"
        printf "  ${BOLD}%-12s${RESET} %s\n" "Vault field" "$vfield"
      fi
    fi

    if prompt_yn "Save this instance?" "Y"; then
      _has_changes=true
      [[ $idx -gt 0 ]] && yaml_content+="\n"
      yaml_content+="  ${name}:\n"
      yaml_content+="    host: ${host}\n"
      yaml_content+="    port: ${port}\n"
      yaml_content+="    username: ${username}\n"
      yaml_content+="    ssl: true\n"
      yaml_content+="    verify_ssl: false\n"
      yaml_content+="    timeout: 600\n"
      yaml_content+="    auth_mode: ${auth_mode}\n"
      if [[ "$auth_mode" == "env" ]]; then
        yaml_content+="    password: ${password}\n"
      else
        yaml_content+="    password_file: ${def_pwfile:-/secure/cclear-password-${idx}}\n"
        if [[ "$use_vault_inst" == "Y" ]]; then
          yaml_content+="    vault_secret_path: ${vpath}\n"
          yaml_content+="    vault_secret_field: ${vfield}\n"
        fi
      fi
      idx=$((idx + 1))
    else
      info "Skipped instance"
    fi

    if [[ $idx -lt $num_existing ]]; then
      continue
    fi

    if ! prompt_yn "Add another cClear instance?" "N"; then
      add_more=false
    fi
  done

  if [[ $idx -eq 0 ]]; then
    warn "No instances configured. Skipping $INSTANCES_FILE"
    return
  fi

  if [[ "$_has_changes" == false ]]; then
    success "No changes made to $INSTANCES_FILE"
    _NEED_VAULT="$_has_vault"
    return
  fi

  confirm_write "$INSTANCES_FILE" || { warn "Skipping $INSTANCES_FILE"; return; }
  printf '%b' "$yaml_content" > "$INSTANCES_FILE"
  chmod 600 "$INSTANCES_FILE"
  success "Wrote $INSTANCES_FILE"

  _NEED_VAULT="$_has_vault"
}

# ---------------------------------------------------------------------------
# vault.env
# ---------------------------------------------------------------------------
create_vault_env() {
  header "Vault Configuration"
  require_tty "Vault configuration"

  local cur_addr="https://vault.example.com:8200" cur_mount="kv"
  if [[ -f "$VAULT_ENV_FILE" ]]; then
    cur_addr=$( grep -m1 '^VAULT_ADDR='  "$VAULT_ENV_FILE" | cut -d= -f2- || true)
    cur_mount=$(grep -m1 '^VAULT_MOUNT=' "$VAULT_ENV_FILE" | cut -d= -f2- || true)
  fi

  # If vault.env already exists, show current config and offer Keep/Edit
  if [[ -f "$VAULT_ENV_FILE" ]]; then
    printf "\n" >"$_TTY_OUT"
    printf "  ${BOLD}── Current Vault Settings ──${RESET}\n" >"$_TTY_OUT"
    printf "  ${BOLD}%-14s${RESET} %s\n" "Vault address" "$cur_addr" >"$_TTY_OUT"
    printf "  ${BOLD}%-14s${RESET} %s\n" "Mount"         "$cur_mount" >"$_TTY_OUT"
    printf "  ${BOLD}%-14s${RESET} %s\n" "Token"         "(prompted at runtime — never stored)" >"$_TTY_OUT"
    printf "\n" >"$_TTY_OUT"

    case "$(prompt_action K Keep E Edit)" in
      K) success "Vault config unchanged."; return ;;
      E) : ;;  # fall through to edit prompts below
    esac
  fi

  local addr mount

  addr=$(prompt_value  "Vault address" "${cur_addr}")
  mount=$(prompt_value "Vault mount"   "${cur_mount}")

  printf '\n'
  info "Review before writing ${VAULT_ENV_FILE}:"
  printf "  ${BOLD}%-14s${RESET} %s\n" "Vault address" "$addr"
  printf "  ${BOLD}%-14s${RESET} %s\n" "Mount"         "$mount"
  printf "  ${BOLD}%-14s${RESET} %s\n" "Token"         "(will be prompted securely at each startup)"
  printf '\n'
  info "Per-instance vault_secret_path and vault_secret_field are configured"
  info "in cclear-instances.yaml alongside each instance."

  confirm_write "$VAULT_ENV_FILE" || { warn "Skipping $VAULT_ENV_FILE"; return; }

  {
    printf 'VAULT_ADDR=%s\n'  "$addr"
    printf 'VAULT_MOUNT=%s\n' "$mount"
  } > "$VAULT_ENV_FILE"
  chmod 600 "$VAULT_ENV_FILE"

  success "Wrote $VAULT_ENV_FILE"
}

# ---------------------------------------------------------------------------
# Orphaned vault.env cleanup
# ---------------------------------------------------------------------------
# When no instance references Vault, vault.env is unused. Offer to remove it,
# defaulting to Keep so a mid-migration setup isn't lost.
cleanup_orphaned_vault_env() {
  [[ -f "$VAULT_ENV_FILE" ]] || return 0
  require_tty "Vault cleanup"

  local addr mount
  addr=$( grep -m1 '^VAULT_ADDR='  "$VAULT_ENV_FILE" | cut -d= -f2- || true)
  mount=$(grep -m1 '^VAULT_MOUNT=' "$VAULT_ENV_FILE" | cut -d= -f2- || true)

  header "Unused Vault Configuration"
  printf "\n" >"$_TTY_OUT"
  printf "  No cClear instances reference Vault, so this file is no longer used.\n" >"$_TTY_OUT"
  printf "\n" >"$_TTY_OUT"
  printf "  ${BOLD}── Orphaned Vault Settings ──${RESET}\n" >"$_TTY_OUT"
  printf "  ${BOLD}%-14s${RESET} %s\n" "Vault address" "${addr:-(unset)}" >"$_TTY_OUT"
  printf "  ${BOLD}%-14s${RESET} %s\n" "Mount"         "${mount:-(unset)}" >"$_TTY_OUT"
  printf "\n" >"$_TTY_OUT"

  case "$(prompt_action K Keep R Remove)" in
    K) info "Keeping $VAULT_ENV_FILE (unused)"; return ;;
    R) rm -f "$VAULT_ENV_FILE"; success "Removed unused $VAULT_ENV_FILE"; return ;;
  esac
}

# ---------------------------------------------------------------------------
# deployment.env  (gateway on/off, Agent Skills on/off)
# ---------------------------------------------------------------------------
# Persist USE_GATEWAY / USE_SKILLS in deployment.env (read by cclear-mcp.sh).

# Render a deployment-config block (gateway + flow + skills). Args: use_gateway use_skills title
_print_deployment_summary() {
  local use_gateway="$1" use_skills="$2" title="$3"
  local gateway_label="disabled" flow="client → cclear-mcp (:8000)"
  if [[ "$use_gateway" == "true" ]]; then
    gateway_label="${GREEN}enabled${RESET}"
    flow="nginx → mcp-proxy → cclear-mcp"
  fi
  local skills_label="disabled"
  if [[ "$use_skills" == "true" ]]; then
    if [[ "$use_gateway" == "true" ]]; then
      skills_label="${GREEN}enabled${RESET}  (via mcp-proxy)"
    else
      skills_label="${GREEN}enabled${RESET}  (:8001)"
    fi
  fi
  printf "\n" >"$_TTY_OUT"
  printf "  ${BOLD}── %s ──${RESET}\n" "$title" >"$_TTY_OUT"
  printf "  ${BOLD}%-8s${RESET} %b\n" "Gateway" "$gateway_label" >"$_TTY_OUT"
  printf "  ${BOLD}%-8s${RESET} %s\n" "Flow"    "$flow" >"$_TTY_OUT"
  printf "  ${BOLD}%-8s${RESET} %b\n" "Skills"  "$skills_label" >"$_TTY_OUT"
}

create_deployment_mode() {
  section_header 2 "Deployment Mode"
  require_tty "Deployment mode"

  local cur_use_gateway="true"
  local cur_use_skills="false"
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]]; then
    local val
    val=$(grep -m1 '^USE_GATEWAY=' "$DEPLOYMENT_ENV_FILE" | cut -d= -f2- || true)
    [[ "$val" == "false" ]] && cur_use_gateway="false"
    local sval
    sval=$(grep -m1 '^USE_SKILLS=' "$DEPLOYMENT_ENV_FILE" | cut -d= -f2- || true)
    [[ "$sval" == "true" ]] && cur_use_skills="true"
  fi

  # If deployment.env already exists, show current config and offer Keep/Edit.
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]]; then
    _print_deployment_summary "$cur_use_gateway" "$cur_use_skills" "Current configuration"
    printf "\n" >"$_TTY_OUT"
    case "$(prompt_action K Keep E Edit)" in
      K)
        success "Deployment mode unchanged."
        # Still offer a pack install when skills is on but none are installed.
        if [[ "$cur_use_skills" == "true" ]]; then
          offer_skills_install
        fi
        return ;;
      E) : ;;  # fall through to edit prompts below
    esac
  fi

  # ---- Gateway (nginx + mcp-proxy) ----
  local use_gateway="true"
  local default_yn="Y"
  [[ "$cur_use_gateway" == "false" ]] && default_yn="N"

  printf "\n" >"$_TTY_OUT"
  printf "  ${BOLD}Gateway${RESET}  ${GREEN}(recommended)${RESET}\n" >"$_TTY_OUT"
  printf "    nginx (TLS) + mcp-proxy (OAuth2/OIDC auth) in front of the MCP stack.\n" >"$_TTY_OUT"
  printf "    Disable only if the stack already sits behind another gateway; without it,\n" >"$_TTY_OUT"
  printf "    cclear-mcp is published directly on :8000 (plain HTTP, no auth).\n" >"$_TTY_OUT"
  if prompt_yn "Run the gateway (nginx + mcp-proxy)?" "$default_yn"; then
    use_gateway="true"
  else
    use_gateway="false"
  fi

  # ---- Agent Skills ----
  local use_skills="false"
  local skills_default="N"
  [[ "$cur_use_skills" == "true" ]] && skills_default="Y"

  printf "\n" >"$_TTY_OUT"
  printf "  ${BOLD}Agent Skills${RESET}  ${CYAN}(optional)${RESET}\n" >"$_TTY_OUT"
  printf "    Runs the agent-skills-mcp container (load_skill / load_skill_resource)\n" >"$_TTY_OUT"
  printf "    from config/skills. With the gateway it is aggregated by mcp-proxy;\n" >"$_TTY_OUT"
  printf "    otherwise the container is published on :8001.\n" >"$_TTY_OUT"
  printf "    Enable only if your agent can't load Agent Skills natively.\n" >"$_TTY_OUT"
  if prompt_yn "Run Agent Skills?" "$skills_default"; then
    use_skills="true"
  fi

  {
    printf 'USE_GATEWAY=%s\n' "$use_gateway"
    printf 'USE_SKILLS=%s\n' "$use_skills"
  } > "$DEPLOYMENT_ENV_FILE"
  chmod 600 "$DEPLOYMENT_ENV_FILE"

  _print_deployment_summary "$use_gateway" "$use_skills" "Selected"
  if [[ "$use_gateway" == "false" ]]; then
    warn "Gateway disabled — cclear-mcp is published directly on :8000 (no TLS, no mcp-proxy auth)."
  fi

  if [[ "$use_skills" == "true" ]]; then
    offer_skills_install
  fi
}

# ---------------------------------------------------------------------------
# Skill pack install (offered when Agent Skills is enabled and none installed)
# ---------------------------------------------------------------------------
SKILLS_HELPER="$SCRIPT_DIR/skills-pack.sh"

offer_skills_install() {
  [[ -x "$SKILLS_HELPER" ]] || return 0
  if "$SKILLS_HELPER" "$CONFIG_DIR" has-skills; then
    return 0
  fi

  printf "\n" >"$_TTY_OUT"
  printf "  ${BOLD}Skill Packs${RESET}\n" >"$_TTY_OUT"
  printf "    No skill pack is installed in config/skills yet. A pack can be\n" >"$_TTY_OUT"
  printf "    installed from the cPacket Artifactory (online), or from a local\n" >"$_TTY_OUT"
  printf "    .zip file (offline).\n" >"$_TTY_OUT"

  case "$(prompt_action A "Install from Artifactory" F "Install from local file" S Skip)" in
    A)
      "$SKILLS_HELPER" "$CONFIG_DIR" install \
        || warn "Skill pack install failed — retry later with ./cclear-mcp.sh skills install"
      ;;
    F)
      local zip_path
      zip_path=$(prompt_value "Path to skill pack .zip" "")
      if [[ -n "$zip_path" ]]; then
        "$SKILLS_HELPER" "$CONFIG_DIR" install --file "$zip_path" \
          || warn "Skill pack install failed — retry later with ./cclear-mcp.sh skills install --file <pack.zip>"
      else
        warn "No path given — install later with ./cclear-mcp.sh skills install --file <pack.zip>"
      fi
      ;;
    S)
      info "Skipped — install later with ./cclear-mcp.sh skills install"
      ;;
  esac
}

# ---------------------------------------------------------------------------
# mcp-proxy-settings.yaml
# ---------------------------------------------------------------------------
# Keep the Agent Skills entry in proxied_servers in sync with USE_SKILLS without
# touching the rest of this user-editable file.

# Re-emit $file with the Agent Skills entry added (want=true) or removed.
_edit_skills_server() {
  local want="$1" file="$2"
  awk -v want="$want" '
    function emit() {
      print "  - name: Agent Skills MCP"
      print "    prefix: skills"
      print "    url: http://agent-skills-mcp:8000/mcp"
    }

    # Remove any existing entry: its name line + the 2 fields below it.
    /name:[[:space:]]*Agent Skills MCP/ { drop = 3 }
    drop { drop--; next }

    # Re-add it (when wanted) where the proxied_servers block ends.
    /^proxied_servers:/ { print; in_block = 1; next }
    in_block && /^[^[:space:]]/ { if (want == "true") emit(); in_block = 0 }
    { print }
    END { if (in_block && want == "true") emit() }
  ' "$file"
}

# Add or remove the Agent Skills entry to match USE_SKILLS. Writes only on change.
_sync_mcp_proxy_skills() {
  local want="false"
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]] && grep -q '^USE_SKILLS=true' "$DEPLOYMENT_ENV_FILE"; then
    want="true"
  fi

  local has="false"
  grep -q 'agent-skills-mcp' "$MCP_PROXY_FILE" && has="true"

  # Already in the wanted state — nothing to do.
  [[ "$want" == "$has" ]] && return 0

  local tmp action="removed"
  [[ "$want" == "true" ]] && action="added"
  tmp="$(mktemp)"
  if _edit_skills_server "$want" "$MCP_PROXY_FILE" >"$tmp" && [[ -s "$tmp" ]]; then
    cat "$tmp" >"$MCP_PROXY_FILE"   # rewrite in place to keep permissions
    success "Updated $(basename "$MCP_PROXY_FILE"): ${action} Agent Skills MCP in proxied_servers"
  fi
  rm -f "$tmp"
}

create_mcp_proxy_settings() {
  # Exists already: just sync the skills entry with USE_SKILLS.
  if [[ -f "$MCP_PROXY_FILE" ]]; then
    _sync_mcp_proxy_skills
    return 0
  fi
  # First run: seed from the example matching the skills choice.
  local example="$MCP_PROXY_EXAMPLE"
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]] && grep -q '^USE_SKILLS=true' "$DEPLOYMENT_ENV_FILE" \
     && [[ -f "$MCP_PROXY_SKILLS_EXAMPLE" ]]; then
    example="$MCP_PROXY_SKILLS_EXAMPLE"
  fi
  if [[ -f "$example" ]]; then
    cp "$example" "$MCP_PROXY_FILE"
    success "Created $MCP_PROXY_FILE from $(basename "$example")"
  fi
}

# ---------------------------------------------------------------------------
# cclear-instances.yaml from example (only if not created by wizard)
# ---------------------------------------------------------------------------
create_instances_from_example() {
  if [[ -f "$INSTANCES_FILE" ]]; then
    return 0
  fi
  if [[ -f "$INSTANCES_EXAMPLE" ]]; then
    cp "$INSTANCES_EXAMPLE" "$INSTANCES_FILE"
    success "Created $INSTANCES_FILE from example (edit to match your setup)"
  fi
}

# ---------------------------------------------------------------------------
# Detect vault usage from existing cclear-instances.yaml
# ---------------------------------------------------------------------------
_yaml_has_vault() {
  [[ -f "$INSTANCES_FILE" ]] && grep -q 'vault_secret_path' "$INSTANCES_FILE"
}

# ---------------------------------------------------------------------------
# Final summary
# ---------------------------------------------------------------------------
# Recap the resulting configuration and point the user at the next command.
print_config_summary() {
  header "Summary"

  if [[ -f "$INSTANCES_FILE" ]]; then
    _EX_NAMES=() _EX_HOSTS=() _EX_PORTS=() _EX_USERS=() _EX_AUTH=() _EX_PWFILES=() _EX_VPATHS=() _EX_VFIELDS=()
    _load_existing_instances "$INSTANCES_FILE"
    local n=${#_EX_NAMES[@]} i
    printf "  ${BOLD}%-18s${RESET} %s\n" "cClear instances" "$n"
    for ((i = 0; i < n; i++)); do
      local cred="${_EX_AUTH[$i]:-docker-secret}"
      [[ -n "${_EX_VPATHS[$i]}" ]] && cred="vault"
      printf "    ${CYAN}•${RESET} %-16s %s:%s  ${BOLD}%s${RESET}\n" \
        "${_EX_NAMES[$i]}" "${_EX_HOSTS[$i]}" "${_EX_PORTS[$i]}" "$cred"
    done
  fi

  local mode="gateway (recommended)"
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]] && grep -q '^USE_GATEWAY=false' "$DEPLOYMENT_ENV_FILE"; then
    mode="no gateway (:8000)"
  fi
  printf "  ${BOLD}%-18s${RESET} %s\n" "Deployment mode" "$mode"

  local skills="disabled"
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]] && grep -q '^USE_SKILLS=true' "$DEPLOYMENT_ENV_FILE"; then
    skills="enabled"
  fi
  printf "  ${BOLD}%-18s${RESET} %s\n" "Agent Skills" "$skills"
  local mf
  for mf in "$CONFIG_DIR/skills/.packs"/*.manifest; do
    [[ -f "$mf" ]] || continue
    printf "  ${BOLD}%-18s${RESET} %s %s\n" "Skill pack" \
      "$(grep -m1 '^pack=' "$mf" | cut -d= -f2)" \
      "$(grep -m1 '^version=' "$mf" | cut -d= -f2)"
  done

  if _yaml_has_vault; then
    printf "  ${BOLD}%-18s${RESET} %s\n" "Vault" "in use"
  elif [[ -f "$VAULT_ENV_FILE" ]]; then
    printf "  ${BOLD}%-18s${RESET} %s\n" "Vault" "configured but unused"
  fi

  success "Configuration saved to $CONFIG_DIR/"
  # Skip the hint when `up` follows or the caller offers a restart itself.
  if [[ "$RECONFIGURE" == "--reconfigure" && "${CCLEAR_STACK_RUNNING:-false}" != "true" ]]; then
    printf "\n${CYAN}${BOLD}==>${RESET} Execute the command below to bring up the stack:\n"
    printf "    ${BOLD}./cclear-mcp.sh up${RESET}\n"
  fi
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

_need_instances=false
_need_vault=false
_NEED_VAULT=false

if [[ ! -f "$INSTANCES_FILE" ]] || [[ "$RECONFIGURE" == "--reconfigure" ]]; then
  _need_instances=true
fi

# Check if vault.env is needed (instances reference vault paths)
if [[ "$_need_instances" == false ]] && _yaml_has_vault; then
  if [[ ! -f "$VAULT_ENV_FILE" ]] || [[ "$RECONFIGURE" == "--reconfigure" ]]; then
    _need_vault=true
  fi
fi

# Silent mode: all required files exist — exit without any output.
if [[ "$_need_instances" == false ]] && [[ "$_need_vault" == false ]]; then
  create_mcp_proxy_settings
  exit 0
fi

# Only vault.env is missing — show a targeted warning before prompting.
if [[ "$_need_instances" == false ]] && [[ "$_need_vault" == true ]]; then
  warn "vault.env not found — Vault credentials must be configured before the stack can start."
fi

if [[ "$_need_instances" == true ]]; then
  _FULL_WIZARD=true
  header "cClear MCP Configuration Setup"
  printf "Config directory: %s\n" "$CONFIG_DIR"
  print_wizard_roadmap
  create_instances_yaml
fi

# After wizard, check if vault is needed from the just-written YAML
if [[ "$_NEED_VAULT" == true ]] || _yaml_has_vault; then
  if [[ ! -f "$VAULT_ENV_FILE" ]] || [[ "$RECONFIGURE" == "--reconfigure" ]]; then
    _need_vault=true
  fi
fi

if [[ "$_need_vault" == true ]]; then
  create_vault_env
elif [[ "$_need_instances" == true ]] && ! _yaml_has_vault; then
  cleanup_orphaned_vault_env
fi

if [[ "$_need_instances" == true ]]; then
  create_deployment_mode
fi

create_mcp_proxy_settings
create_instances_from_example

print_config_summary
