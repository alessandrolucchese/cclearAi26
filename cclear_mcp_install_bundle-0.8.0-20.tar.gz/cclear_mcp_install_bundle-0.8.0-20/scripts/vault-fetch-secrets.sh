#!/bin/sh
set -e

INSTANCES_FILE="/config/cclear-instances.yaml"

[ -f "$INSTANCES_FILE" ] || { echo "ERROR: $INSTANCES_FILE not found" >&2; exit 1; }
[ -n "${VAULT_ADDR:-}" ]  || { echo "ERROR: VAULT_ADDR is not set"  >&2; exit 1; }
[ -n "${VAULT_TOKEN:-}" ] || { echo "ERROR: VAULT_TOKEN is not set" >&2; exit 1; }
[ -n "${VAULT_MOUNT:-}" ] || { echo "ERROR: VAULT_MOUNT is not set" >&2; exit 1; }

echo "Fetching Vault secrets defined in $INSTANCES_FILE"
fetched=0
current_pwfile="" current_vpath="" current_vfield=""

flush_secret() {
  if [ -n "$current_vpath" ] && [ -n "$current_pwfile" ]; then
    field="${current_vfield:-value}"
    echo "  $current_vpath (field: $field) -> $current_pwfile"

    # Fetch into a variable first so a failed/empty read never leaves a
    # truncated password file in the shared volume.
    if ! secret=$(vault kv get -mount="$VAULT_MOUNT" -field="$field" "$current_vpath"); then
      echo "ERROR: could not read '$current_vpath' (field '$field') from Vault" >&2
      exit 1
    fi
    if [ -z "$secret" ]; then
      echo "ERROR: Vault returned an empty value for '$current_vpath' (field '$field')" >&2
      exit 1
    fi

    printf '%s' "$secret" > "$current_pwfile"
    chmod 600 "$current_pwfile"
    fetched=$((fetched + 1))
  fi
  current_pwfile="" current_vpath="" current_vfield=""
}

while IFS= read -r line || [ -n "$line" ]; do
  case "$line" in
    *"password_file:"*)      current_pwfile=$(echo "$line" | sed 's/.*password_file:[[:space:]]*//') ;;
    *"vault_secret_path:"*)  current_vpath=$(echo "$line"  | sed 's/.*vault_secret_path:[[:space:]]*//') ;;
    *"vault_secret_field:"*) current_vfield=$(echo "$line" | sed 's/.*vault_secret_field:[[:space:]]*//') ;;
    "  "[a-zA-Z]*)           flush_secret ;;
  esac
done < "$INSTANCES_FILE"
flush_secret

[ "$fetched" -gt 0 ] || { echo "ERROR: no Vault-backed secrets found in $INSTANCES_FILE" >&2; exit 1; }

echo "Done — $fetched secret(s) fetched from Vault."
