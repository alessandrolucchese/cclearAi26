#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# shellcheck source=scripts/term.sh
. "$SCRIPT_DIR/scripts/term.sh"

# Portable `mapfile`/`readarray` replacement (bash 3.2+).
# Usage: read_into <array_var> < <(command)
read_into() {
  local arr_name="$1"
  local line

  if [[ ! "$arr_name" =~ ^[a-zA-Z_][a-zA-Z0-9_]*$ ]]; then
    err "read_into: invalid variable name: $arr_name"
    return 1
  fi

  eval "${arr_name}=()"
  while IFS= read -r line; do
    eval "${arr_name}+=(\"\$line\")"
  done
}

usage() {
  printf "${BOLD}Usage:${RESET} ./cclear-mcp.sh <command>\n\n"
  printf "${BOLD}Commands:${RESET}\n"
  printf "  ${CYAN}%-16s${RESET} %s\n" "help"         "Show this help"
  printf "  ${CYAN}%-16s${RESET} %s\n" "up"           "Start the stack (runs config wizard if needed)"
  printf "  ${CYAN}%-16s${RESET} %s\n" "down"         "Stop the stack"
  printf "  ${CYAN}%-16s${RESET} %s\n" "restart"      "Restart the stack"
  printf "  ${CYAN}%-16s${RESET} %s\n" "status"       "Show service status"
  printf "  ${CYAN}%-16s${RESET} %s\n" "logs"         "Show logs (pass -- [service] [-f] for options)"
  printf "  ${CYAN}%-16s${RESET} %s\n" "config"       "Re-run configuration wizard"
  printf "  ${CYAN}%-16s${RESET} %s\n" "config show"  "Display current configuration"
  printf "  ${CYAN}%-16s${RESET} %s\n" "skills"       "Manage Agent Skill packs (install | download | list | remove)"
  printf "  ${CYAN}%-16s${RESET} %s\n" "version"      "Show bundle and service versions"
  printf "\n${BOLD}Skill packs:${RESET}\n"
  printf "  ${CYAN}%s${RESET}\n" "skills install [pack] [--version <v>]   # install from cPacket Artifactory"
  printf "  ${CYAN}%s${RESET}\n" "skills install --file <pack.zip>        # install from a local file (offline)"
  printf "  ${CYAN}%s${RESET}\n" "skills download [pack] [--version <v>]  # download zip only, no install (offline transfer)"
  printf "  ${CYAN}%s${RESET}\n" "skills list                             # show the installed pack and skills"
  printf "  ${CYAN}%s${RESET}\n" "skills remove [pack]                    # remove the installed pack"
}

# -----------------------------
# Config (defaults)
# -----------------------------
PASSWORD_FILE_DEFAULT="/secure/cclear-password"
CONTAINER_NAME="cclear-mcp"
PROXY_CONTAINER_NAME="mcp-proxy"
SKILLS_CONTAINER_NAME="agent-skills-mcp"
NGINX_CONTAINER_NAME="mcp-nginx"
PROJECT_NAME="${COMPOSE_PROJECT_NAME:-cclear-mcp}"
TLS_DIR="$SCRIPT_DIR/compose/config/tls"
TLS_CERT="$TLS_DIR/server.crt"
TLS_KEY="$TLS_DIR/server.key"
CONFIG_DIR="$SCRIPT_DIR/compose/config"
INSTANCES_FILE="$CONFIG_DIR/cclear-instances.yaml"
DEPLOYMENT_ENV_FILE="$CONFIG_DIR/deployment.env"

# Set by load_env
HAS_VAULT_INSTANCES=false
HAS_DOCKER_SECRET_INSTANCES=false

# Deployment toggles (from deployment.env). Gateway = nginx + mcp-proxy;
# Skills = the agent-skills-mcp container.
USE_GATEWAY=true
USE_SKILLS=false

# -----------------------------
# Helpers
# -----------------------------
is_vault_mode() {
  [[ "$HAS_VAULT_INSTANCES" == true ]]
}

# Read USE_GATEWAY / USE_SKILLS from deployment.env.
load_deployment_mode() {
  USE_GATEWAY=true
  USE_SKILLS=false
  if [[ -f "$DEPLOYMENT_ENV_FILE" ]]; then
    local val
    val=$(grep -m1 '^USE_GATEWAY=' "$DEPLOYMENT_ENV_FILE" | cut -d= -f2- || true)
    if [[ "$val" == "false" ]]; then
      USE_GATEWAY=false
    fi
    local sval
    sval=$(grep -m1 '^USE_SKILLS=' "$DEPLOYMENT_ENV_FILE" | cut -d= -f2- || true)
    if [[ "$sval" == "true" ]]; then
      USE_SKILLS=true
    fi
  fi
}

is_gateway_mode() {
  [[ "$USE_GATEWAY" == true ]]
}

is_skills_mode() {
  [[ "$USE_SKILLS" == true ]]
}

compose_args() {
  printf '%s\n' "-f" "docker-compose.yml"
  if is_vault_mode; then
    printf '%s\n' "-f" "docker-compose.vault.yml"
  fi
  if is_skills_mode; then
    printf '%s\n' "-f" "docker-compose.skills.yml"
  fi
  if ! is_gateway_mode; then
    printf '%s\n' "-f" "docker-compose.standalone.yml"
    if is_skills_mode; then
      printf '%s\n' "-f" "docker-compose.standalone-skills.yml"
    fi
  fi
}

compose_services() {
  printf '%s\n' "cclear-mcp"
  if is_skills_mode; then
    printf '%s\n' "agent-skills-mcp"
  fi
  if is_gateway_mode; then
    printf '%s\n' "mcp-proxy"
    printf '%s\n' "nginx"
  fi
}

container_exists() {
  docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"
}

container_image() {
  local name="$1"
  if ! command -v docker >/dev/null 2>&1; then
    return 0
  fi
  docker ps --filter "name=${name}" --format '{{.Image}}' | head -n1 || true
}

ensure_tls_certs() {
  # TLS is only terminated by nginx, which runs in gateway mode only.
  if ! is_gateway_mode; then
    return 0
  fi
  if [[ -f "$TLS_CERT" && -f "$TLS_KEY" ]]; then
    return 0
  fi
  warn "TLS certificates not found at:"
  printf "   %s\n" "$TLS_CERT"
  printf "   %s\n" "$TLS_KEY"
  require_tty "TLS certificate setup"
  printf "Generate self-signed certs now? [y/N]: " >"$_TTY_OUT"
  local ans
  read -r ans <"$_TTY_IN"
  if [[ "$ans" =~ ^[Yy]$ ]]; then
    local gen="$SCRIPT_DIR/scripts/tls-self-sign.sh"
    if [[ ! -x "$gen" ]]; then
      err "Generator not found or not executable: $gen"
      exit 1
    fi
    local default_host
    default_host="$(hostname -f 2>/dev/null || hostname)"
    printf "Hostname for certificate [%s]: " "$default_host" >"$_TTY_OUT"
    local host
    read -r host <"$_TTY_IN"
    if [[ -n "$host" ]]; then
      "$gen" "$host"
    else
      "$gen"
    fi
  else
    err "TLS certificates missing; cannot start nginx with HTTPS"
    printf "   Run: ./scripts/tls-self-sign.sh\n" >&2
    exit 1
  fi
}

# -----------------------------
# Password handling (tmpfs)
# -----------------------------
prompt_password() {
  local host="${1:-${CCLEAR_HOST:-unknown}}"
  local user="${2:-${CCLEAR_USERNAME:-unknown}}"
  local password confirm
  require_tty "password prompt"

  printf "cClear host    : %s\n" "$host"
  printf "cClear username: %s\n" "$user"

  printf "Enter cClear password: " >"$_TTY_OUT"
  if read -rs password <"$_TTY_IN" 2>/dev/null; then
    printf '\n' >"$_TTY_OUT"
  else
    read -r password <"$_TTY_IN"
  fi

  printf "Confirm password: " >"$_TTY_OUT"
  if read -rs confirm <"$_TTY_IN" 2>/dev/null; then
    printf '\n' >"$_TTY_OUT"
  else
    read -r confirm <"$_TTY_IN"
  fi

  [[ "$password" == "$confirm" ]] || { err "Password mismatch"; exit 1; }
  [[ -n "$password" ]]           || { err "Empty password not allowed"; exit 1; }

  USER_PASSWORD="$password"
}

inject_password_into_container() {
  local pw_file="$1"
  info "Injecting password into container (${pw_file})..."

  if ! printf '%s' "$USER_PASSWORD" | docker exec -i "$CONTAINER_NAME" sh -c \
    'cat > "$1" && chmod 600 "$1"' _ "$pw_file"; then
    err "Failed to inject password"
    docker logs "$CONTAINER_NAME" | tail -n 20 || true
    exit 1
  fi

  success "Password written to ${pw_file}"
}

password_exists_in_container() {
  local pw_file="$1"
  docker exec "$CONTAINER_NAME" sh -c '[ -s "$1" ]' _ "$pw_file" >/dev/null 2>&1
}

ensure_password_tmpfs() {
  local i
  for ((i = 0; i < ${#INSTANCE_NAMES[@]}; i++)); do
    local name="${INSTANCE_NAMES[$i]}"
    local auth="${INSTANCE_AUTH_MODES[$i]}"
    local pw_file="${INSTANCE_PASSWORD_FILES[$i]}"
    local host="${INSTANCE_HOSTS[$i]}"
    local user="${INSTANCE_USERNAMES[$i]}"

    if [[ "$auth" != "docker-secret" ]]; then
      continue
    fi

    if password_exists_in_container "$pw_file"; then
      success "Password already present for instance '${name}'"
      continue
    fi

    warn "No password found for instance '${name}' (${host})"
    prompt_password "$host" "$user"
    inject_password_into_container "$pw_file"
  done
}

wait_for_container() {
  info "Waiting for container to be ready..."

  local i
  for ((i = 1; i <= 30; i++)); do
    if ! container_exists; then
      err "Container $CONTAINER_NAME not found"
      exit 1
    fi

    if docker exec "$CONTAINER_NAME" true >/dev/null 2>&1; then
      return 0
    fi

    sleep 1
  done

  err "Container not ready after timeout"
  exit 1
}

# -----------------------------
# Load env
# -----------------------------
cmd="${1:-help}"

CONFIG_HELPER="$SCRIPT_DIR/scripts/cclear-config.sh"
SKILLS_HELPER="$SCRIPT_DIR/scripts/skills-pack.sh"

# Per-instance arrays populated by load_env (parallel indices).
INSTANCE_NAMES=()
INSTANCE_AUTH_MODES=()
INSTANCE_PASSWORD_FILES=()
INSTANCE_HOSTS=()
INSTANCE_USERNAMES=()

load_env() {
  INSTANCE_NAMES=()
  INSTANCE_AUTH_MODES=()
  INSTANCE_PASSWORD_FILES=()
  INSTANCE_HOSTS=()
  INSTANCE_USERNAMES=()
  INSTANCE_PORTS=()
  INSTANCE_VAULT_PATHS=()
  HAS_VAULT_INSTANCES=false
  HAS_DOCKER_SECRET_INSTANCES=false

  if [[ ! -f "$INSTANCES_FILE" ]]; then
    err "cclear-instances.yaml not found at $INSTANCES_FILE"
    printf "  Run: ./cclear-mcp.sh config\n" >&2
    exit 1
  fi

  _load_instances_from_yaml "$INSTANCES_FILE"
  load_deployment_mode

  # Detect vault / docker-secret usage from parsed instances.
  local i
  for ((i = 0; i < ${#INSTANCE_AUTH_MODES[@]}; i++)); do
    if [[ "${INSTANCE_AUTH_MODES[$i]}" == "docker-secret" ]]; then
      HAS_DOCKER_SECRET_INSTANCES=true
      if [[ -n "${INSTANCE_VAULT_PATHS[$i]:-}" ]]; then
        HAS_VAULT_INSTANCES=true
      fi
    fi
  done
}

# Minimal line-based parser for cclear-instances.yaml (no YAML lib needed).
INSTANCE_VAULT_PATHS=()
INSTANCE_PORTS=()

_load_instances_from_yaml() {
  local file="$1"
  local current_name="" current_host="" current_port="" current_user="" current_auth="" current_pwfile="" current_vpath=""

  while IFS= read -r line; do
    # Skip comments and empty lines
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ -z "${line// /}" ]] && continue

    # Detect instance name (2-space indented key with colon, no value)
    if [[ "$line" =~ ^[[:space:]]{2}([a-zA-Z0-9_-]+):[[:space:]]*$ ]]; then
      # Save previous instance if any
      if [[ -n "$current_name" ]]; then
        INSTANCE_NAMES+=("$current_name")
        INSTANCE_HOSTS+=("${current_host:-unknown}")
        INSTANCE_PORTS+=("${current_port:-443}")
        INSTANCE_USERNAMES+=("${current_user:-unknown}")
        INSTANCE_AUTH_MODES+=("${current_auth:-env}")
        INSTANCE_PASSWORD_FILES+=("${current_pwfile:-$PASSWORD_FILE_DEFAULT}")
        INSTANCE_VAULT_PATHS+=("${current_vpath}")
      fi
      current_name="${BASH_REMATCH[1]}"
      current_host="" current_port="" current_user="" current_auth="" current_pwfile="" current_vpath=""
      continue
    fi

    # Parse key: value (4-space indented)
    if [[ "$line" =~ ^[[:space:]]{4}([a-z_]+):[[:space:]]*(.+)$ ]]; then
      local key="${BASH_REMATCH[1]}" val="${BASH_REMATCH[2]}"
      case "$key" in
        host)              current_host="$val" ;;
        port)              current_port="$val" ;;
        username)          current_user="$val" ;;
        auth_mode)         current_auth="$val" ;;
        password_file)     current_pwfile="$val" ;;
        vault_secret_path) current_vpath="$val" ;;
      esac
    fi
  done < "$file"

  # Save last instance
  if [[ -n "$current_name" ]]; then
    INSTANCE_NAMES+=("$current_name")
    INSTANCE_HOSTS+=("${current_host:-unknown}")
    INSTANCE_PORTS+=("${current_port:-443}")
    INSTANCE_USERNAMES+=("${current_user:-unknown}")
    INSTANCE_AUTH_MODES+=("${current_auth:-env}")
    INSTANCE_PASSWORD_FILES+=("${current_pwfile:-$PASSWORD_FILE_DEFAULT}")
    INSTANCE_VAULT_PATHS+=("${current_vpath}")
  fi
}

ensure_vault_env() {
  if is_vault_mode && [[ ! -f "$CONFIG_DIR/vault.env" ]]; then
    err "vault.env not found at $CONFIG_DIR/vault.env"
    printf "  Instances with vault_secret_path require vault.env for connection settings.\n" >&2
    printf "  Run: ./cclear-mcp.sh config\n" >&2
    exit 1
  fi
}

# Prompt for the Vault token interactively (never stored on disk).
prompt_vault_token() {
  if [[ -n "${VAULT_TOKEN:-}" ]]; then
    return 0
  fi
  require_tty "Vault token prompt"
  local token=""
  while [[ -z "$token" ]]; do
    printf "${BOLD}🔐 Enter Vault Token${RESET}: " >"$_TTY_OUT"
    if read -rs token <"$_TTY_IN" 2>/dev/null; then
      printf '\n' >"$_TTY_OUT"
    else
      read -r token <"$_TTY_IN"
      printf '\n' >"$_TTY_OUT"
    fi
    if [[ -z "$token" ]]; then
      warn "Vault token is required."
    fi
  done
  export VAULT_TOKEN="$token"
}

# Vault mode: fetch every instance password into the shared secrets volume by
# running vault-cli once in the foreground. Fails fast with the fetch logs
# visible, so the stack never starts with missing or empty passwords.
# Requires compose_flags to be populated by the caller.
fetch_vault_secrets() {
  info "Fetching secrets from Vault..."
  if ! docker compose "${compose_flags[@]}" run --rm vault-cli; then
    err "Failed to fetch secrets from Vault — stack not started."
    err "Check the Vault address, token, mount, and per-instance secret paths, then retry."
    exit 1
  fi
  success "Secrets fetched from Vault."
}

# True when at least one skill exists in config/skills.
skills_installed() {
  [[ -x "$SKILLS_HELPER" ]] && "$SKILLS_HELPER" "$CONFIG_DIR" has-skills
}

# True when any stack container is running.
stack_running() {
  docker ps --format '{{.Names}}' 2>/dev/null \
    | grep -qE "^(${CONTAINER_NAME}|${PROXY_CONTAINER_NAME}|${SKILLS_CONTAINER_NAME}|${NGINX_CONTAINER_NAME})$"
}

# Checksum of the config files (used to detect wizard changes).
config_checksum() {
  find "$CONFIG_DIR" -type f \
    \( -name '*.yaml' -o -name '*.env' -o -name '*.manifest' \) \
    -exec cksum {} + 2>/dev/null | sort | cksum
}

adopt_legacy_resources() {
  local name project
  for name in "$CONTAINER_NAME" "$PROXY_CONTAINER_NAME" "$SKILLS_CONTAINER_NAME" "$NGINX_CONTAINER_NAME"; do
    project=$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}}' "$name" 2>/dev/null) || continue
    if [[ "$project" != "$PROJECT_NAME" ]]; then
      info "Adopting container '$name' from previous install (project '${project:-none}')..."
      docker rm -f "$name" >/dev/null 2>&1 || true
    fi
  done
  # Fixed-name network and tmpfs secrets volume: recreate when labeled with an
  # old project so compose stops warning. Skipped while still in use; the
  # volume is a tmpfs whose contents are re-provisioned on every start anyway.
  project=$(docker network inspect cclear-mcp-net --format '{{index .Labels "com.docker.compose.project"}}' 2>/dev/null) || project="$PROJECT_NAME"
  if [[ "$project" != "$PROJECT_NAME" ]]; then
    docker network rm cclear-mcp-net >/dev/null 2>&1 || true
  fi
  project=$(docker volume inspect cclear-secrets --format '{{index .Labels "com.docker.compose.project"}}' 2>/dev/null) || project="$PROJECT_NAME"
  if [[ "$project" != "$PROJECT_NAME" ]]; then
    docker volume rm cclear-secrets >/dev/null 2>&1 || true
  fi
}

# Full stack restart (down + up with current config).
do_restart() {
  load_env
  ensure_vault_env
  if is_vault_mode; then
    prompt_vault_token
  fi
  ensure_tls_certs
  local compose_flags services
  read_into compose_flags < <(compose_args)
  read_into services < <(compose_services)
  docker compose "${compose_flags[@]}" down --remove-orphans
  adopt_legacy_resources
  if is_vault_mode; then
    fetch_vault_secrets
  fi
  docker compose "${compose_flags[@]}" up -d --remove-orphans "${services[@]}"

  report_and_provision
}

# Shared tail of `up`/`restart`: report mode, provision docker-secret passwords.
report_and_provision() {
  if is_gateway_mode; then
    info "Gateway: enabled (nginx → mcp-proxy → cclear-mcp)"
    if is_skills_mode; then
      info "Agent Skills: enabled (aggregated by mcp-proxy)"
    fi
  else
    warn "Gateway: disabled — cclear-mcp is published directly on :8000 (no TLS, no mcp-proxy auth)"
    if is_skills_mode; then
      info "Agent Skills: enabled (published on :8001)"
    fi
  fi

  if is_skills_mode && ! skills_installed; then
    warn "Agent Skills is enabled but no skill packs are installed in compose/config/skills/"
    printf "   Install with: ./cclear-mcp.sh skills install                      (from cPacket Artifactory)\n" >&2
    printf "             or: ./cclear-mcp.sh skills install --file <pack.zip>    (offline)\n" >&2
  fi

  if is_vault_mode; then
    info "Using Vault backend"
  elif [[ "$HAS_DOCKER_SECRET_INSTANCES" == true ]]; then
    wait_for_container
    ensure_password_tmpfs
  fi

  print_connect_info
}

# Primary IPv4 address of this host ("" when undetectable).
primary_ipv4() {
  local ip
  ip=$(hostname -I 2>/dev/null | awk '{print $1}')
  [[ -z "$ip" ]] && ip=$(ip -4 route get 1.1.1.1 2>/dev/null \
    | grep -oE 'src [0-9.]+' | awk '{print $2}')
  [[ -z "$ip" ]] && ip=$(ifconfig 2>/dev/null \
    | grep -oE 'inet (addr:)?([0-9]+\.){3}[0-9]+' \
    | grep -oE '([0-9]+\.){3}[0-9]+' | grep -v '^127\.' | head -n1)
  printf '%s' "$ip"
}

# Where clients connect, resolved from the active config.
print_connect_info() {
  # hostname -f is not universal (e.g. Git Bash) — fall back gracefully.
  local host ip
  host=$(hostname -f 2>/dev/null)
  [[ -z "$host" ]] && host=$(hostname 2>/dev/null)
  [[ -z "$host" ]] && host=localhost
  ip=$(primary_ipv4)
  printf '\n'
  info "Connect your MCP client to:"
  if is_gateway_mode; then
    local url
    url=$(awk '
      /^service:/ { s = 1; next }
      s && /^[^[:space:]]/ { s = 0 }
      s && /^[[:space:]]+url:/ { sub(/^[[:space:]]+url:[[:space:]]*/, ""); print; exit }
    ' "$CONFIG_DIR/mcp-proxy-settings.yaml" 2>/dev/null)
    url="${url:-https://localhost/}"
    url="${url%/}/mcp"
    # Show a reachable address while the public URL is still the default.
    if [[ "$url" == *"//localhost"* ]]; then
      url="${url%%//localhost*}//${host}${url#*//localhost}"
    fi
    printf "    ${BOLD}%s${RESET}\n" "$url"
    if [[ -n "$ip" && "$url" != *"//$ip"* ]]; then
      local scheme="${url%%://*}" authority port="" path
      authority="${url#*://}"
      authority="${authority%%/*}"
      [[ "$authority" == *:* ]] && port=":${authority##*:}"
      path="${url#*"$authority"}"
      printf "    ${BOLD}%s://%s%s%s${RESET}   (via IP)\n" "$scheme" "$ip" "$port" "$path"
    fi
  else
    # Pad URLs so the service annotations line up.
    local u1="http://$host:8000/mcp" u2="http://$host:8001/mcp"
    local i1="" i2="" width=${#u1}
    if [[ -n "$ip" ]]; then
      i1="http://$ip:8000/mcp"
      i2="http://$ip:8001/mcp"
    fi
    printf "    ${BOLD}%-*s${RESET}   (cClear MCP)\n" "$width" "$u1"
    [[ -n "$i1" ]] && printf "    ${BOLD}%-*s${RESET}   (cClear MCP)\n" "$width" "$i1"
    if is_skills_mode; then
      printf "    ${BOLD}%-*s${RESET}   (Agent Skills)\n" "$width" "$u2"
      [[ -n "$i2" ]] && printf "    ${BOLD}%-*s${RESET}   (Agent Skills)\n" "$width" "$i2"
    fi
  fi
}

# -----------------------------
# config show (human-friendly)
# -----------------------------
# Read VALUE for KEY=VALUE from an env-style file (first match only).
_env_get() {
  local file="$1" key="$2"
  [[ -f "$file" ]] || return 0
  grep -m1 "^${key}=" "$file" | cut -d= -f2- || true
}

# True when a PEM cert is self-signed (subject equals issuer); 2 if unreadable.
_cert_is_self_signed() {
  local cert="$1" subject issuer
  subject=$(openssl x509 -in "$cert" -noout -subject 2>/dev/null) || return 2
  issuer=$( openssl x509 -in "$cert" -noout -issuer  2>/dev/null) || return 2
  [[ "${subject#*=}" == "${issuer#*=}" ]]
}

# Summarized view of the active config; `config show --raw` dumps full files.
config_show() {
  header "Current Configuration"
  printf "  ${BOLD}%-11s${RESET} %s\n" "Config dir" "$CONFIG_DIR"

  # ---- Instances ----
  if [[ -f "$INSTANCES_FILE" ]]; then
    INSTANCE_NAMES=() INSTANCE_AUTH_MODES=() INSTANCE_PASSWORD_FILES=()
    INSTANCE_HOSTS=() INSTANCE_USERNAMES=() INSTANCE_VAULT_PATHS=() INSTANCE_PORTS=()
    _load_instances_from_yaml "$INSTANCES_FILE"

    local n=${#INSTANCE_NAMES[@]} i
    printf "\n  ${BOLD}cClear Instances${RESET} (%s)\n" "$n"
    for ((i = 0; i < n; i++)); do
      local cred
      if [[ -n "${INSTANCE_VAULT_PATHS[$i]}" ]]; then
        cred="vault → ${INSTANCE_VAULT_PATHS[$i]}"
      elif [[ "${INSTANCE_AUTH_MODES[$i]}" == "env" ]]; then
        cred="env (password stored in YAML)"
      else
        cred="docker-secret (tmpfs)"
      fi
      printf "\n    ${CYAN}%s${RESET}\n" "${INSTANCE_NAMES[$i]}"
      printf "      %-11s %s:%s\n" "Host"       "${INSTANCE_HOSTS[$i]}" "${INSTANCE_PORTS[$i]}"
      printf "      %-11s %s\n"    "Username"   "${INSTANCE_USERNAMES[$i]}"
      printf "      %-11s %s\n"    "Credential" "$cred"
    done
  else
    warn "No cclear-instances.yaml found — run ./cclear-mcp.sh config"
  fi

  # ---- Deployment ----
  load_deployment_mode
  printf "\n  ${BOLD}Deployment${RESET}\n"
  if is_gateway_mode; then
    printf "      %-11s %s\n" "Gateway" "enabled"
    printf "      %-11s %s\n" "Path" "nginx → mcp-proxy → cclear-mcp"
    local proxy_file="$CONFIG_DIR/mcp-proxy-settings.yaml"
    if [[ -f "$proxy_file" ]]; then
      local auth_enable proxied
      auth_enable=$(grep -m1 -E '^[[:space:]]+enable:[[:space:]]' "$proxy_file" | awk '{print $2}')
      proxied=$(grep -E '^[[:space:]]+url:[[:space:]]' "$proxy_file" | tail -n1 | awk '{print $2}')
      if [[ "$auth_enable" == "true" ]]; then
        printf "      %-11s ${GREEN}%s${RESET}\n" "MCP auth" "enabled"
      else
        printf "      %-11s ${YELLOW}%s${RESET}\n" "MCP auth" "disabled"
      fi
      [[ -n "$proxied" ]] && printf "      %-11s %s\n" "Forwards to" "$proxied"
    fi
  else
    printf "      %-11s %s\n" "Gateway" "disabled"
    printf "      %-11s %s\n" "Path" "client → cclear-mcp (:8000)"
    printf "      %-11s ${YELLOW}%s${RESET}\n" "MCP auth" "none (no mcp-proxy, no TLS)"
  fi
  if is_skills_mode; then
    if is_gateway_mode; then
      printf "      %-11s ${GREEN}%s${RESET}\n" "Skills" "enabled (via mcp-proxy)"
    else
      printf "      %-11s ${GREEN}%s${RESET}\n" "Skills" "enabled (:8001)"
    fi
    local packs="" mf
    for mf in "$CONFIG_DIR/skills/.packs"/*.manifest; do
      [[ -f "$mf" ]] || continue
      packs="${packs:+$packs, }$(grep -m1 '^pack=' "$mf" | cut -d= -f2) $(grep -m1 '^version=' "$mf" | cut -d= -f2)"
    done
    if [[ -n "$packs" ]]; then
      printf "      %-11s %s\n" "Packs" "$packs"
    elif skills_installed; then
      printf "      %-11s %s\n" "Packs" "none (manually added skills present)"
    else
      printf "      %-11s ${YELLOW}%s${RESET}\n" "Packs" "none — run ./cclear-mcp.sh skills install"
    fi
  else
    printf "      %-11s %s\n" "Skills" "disabled"
  fi

  # ---- TLS ----
  printf "\n  ${BOLD}TLS${RESET}\n"
  if [[ -f "$TLS_CERT" && -f "$TLS_KEY" ]]; then
    if command -v openssl >/dev/null 2>&1; then
      local cn enddate
      cn=$(openssl x509 -in "$TLS_CERT" -noout -subject 2>/dev/null | sed -n 's/.*CN *= *\([^,/]*\).*/\1/p')
      enddate=$(openssl x509 -in "$TLS_CERT" -noout -enddate 2>/dev/null | cut -d= -f2)
      if _cert_is_self_signed "$TLS_CERT"; then
        printf "      %-11s ${YELLOW}%s${RESET}\n" "Certificate" "self-signed"
      else
        printf "      %-11s ${GREEN}%s${RESET}\n" "Certificate" "CA-signed"
      fi
      [[ -n "$cn" ]] && printf "      %-11s %s\n" "Subject CN" "$cn"
      if [[ -n "$enddate" ]]; then
        if openssl x509 -in "$TLS_CERT" -noout -checkend 0 >/dev/null 2>&1; then
          printf "      %-11s %s\n" "Expires" "$enddate"
        else
          printf "      %-11s ${RED}%s (expired)${RESET}\n" "Expires" "$enddate"
        fi
      fi
    else
      printf "      %-11s %s\n" "Certificate" "present (install openssl for details)"
    fi
  else
    printf "      %-11s ${RED}%s${RESET}\n" "Certificate" "missing — generated on next ./cclear-mcp.sh up"
  fi

  # ---- Vault ----
  local vault_file="$CONFIG_DIR/vault.env"
  if [[ -f "$vault_file" ]]; then
    local vault_in_use=false i
    for ((i = 0; i < ${#INSTANCE_VAULT_PATHS[@]}; i++)); do
      [[ -n "${INSTANCE_VAULT_PATHS[$i]}" ]] && vault_in_use=true
    done
    if [[ "$vault_in_use" == true ]]; then
      printf "\n  ${BOLD}Vault${RESET}\n"
    else
      printf "\n  ${BOLD}Vault${RESET} ${YELLOW}(configured but unused)${RESET}\n"
    fi
    printf "      %-11s %s\n" "Address" "$(_env_get "$vault_file" VAULT_ADDR)"
    printf "      %-11s %s\n" "Mount"   "$(_env_get "$vault_file" VAULT_MOUNT)"
    printf "      %-11s %s\n" "Token"   "prompted at runtime — never stored"
  fi

  printf "\n  ${CYAN}Tip:${RESET} full file contents with ${BOLD}./cclear-mcp.sh config show --raw${RESET}\n"
}

cd "$SCRIPT_DIR/compose"

# -----------------------------
# Commands
# -----------------------------
case "$cmd" in
  help|-h|--help)
    usage
    ;;

  version|--version)
    version="unknown"
    if [[ -f "$SCRIPT_DIR/VERSION" ]]; then
      version="$(<"$SCRIPT_DIR/VERSION")"
    fi
    printf "cclear-mcp bundle version: %s\n" "$version"
    image_cclear="$(container_image "$CONTAINER_NAME")"
    image_proxy="$(container_image "$PROXY_CONTAINER_NAME")"
    image_skills="$(container_image "$SKILLS_CONTAINER_NAME")"
    if [[ -n "$image_cclear" || -n "$image_proxy" || -n "$image_skills" ]]; then
      printf "services:\n"
      if [[ -n "$image_cclear" ]]; then
        printf "  cclear-mcp       : %s\n" "$image_cclear"
      fi
      if [[ -n "$image_proxy" ]]; then
        printf "  mcp-proxy        : %s\n" "$image_proxy"
      fi
      if [[ -n "$image_skills" ]]; then
        printf "  agent-skills-mcp : %s\n" "$image_skills"
      fi
    fi
    packs_header=false
    for mf in "$CONFIG_DIR/skills/.packs"/*.manifest; do
      [[ -f "$mf" ]] || continue
      if [[ "$packs_header" == false ]]; then
        printf "skill packs:\n"
        packs_header=true
      fi
      printf "  %-18s : %s\n" \
        "$(grep -m1 '^pack=' "$mf" | cut -d= -f2)" \
        "$(grep -m1 '^version=' "$mf" | cut -d= -f2)"
    done
    ;;

  set-password)
    load_env
    wait_for_container

    # If multiple instances, let user pick which one
    selected_idx=0
    if [[ ${#INSTANCE_NAMES[@]} -gt 1 ]]; then
      printf '\n' >"$_TTY_OUT"
      printf "${BOLD}Select instance to set password for:${RESET}\n" >"$_TTY_OUT"
      for ((idx = 0; idx < ${#INSTANCE_NAMES[@]}; idx++)); do
        printf "  ${CYAN}[%s]${RESET} %s (%s)\n" "$((idx + 1))" "${INSTANCE_NAMES[$idx]}" "${INSTANCE_HOSTS[$idx]}" >"$_TTY_OUT"
      done
      while true; do
        printf "${BOLD}Choice${RESET} [1]: " >"$_TTY_OUT"
        read -r choice <"$_TTY_IN"
        choice="${choice:-1}"
        if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#INSTANCE_NAMES[@]} )); then
          selected_idx=$((choice - 1))
          break
        fi
        warn "Enter a number between 1 and ${#INSTANCE_NAMES[@]}."
      done
    fi

    name="${INSTANCE_NAMES[$selected_idx]}"
    host="${INSTANCE_HOSTS[$selected_idx]}"
    user="${INSTANCE_USERNAMES[$selected_idx]}"
    pw_file="${INSTANCE_PASSWORD_FILES[$selected_idx]}"

    info "Setting password for instance '${name}' (${host})"

    prompt_password "$host" "$user"

    inject_password_into_container "$pw_file"

    # The MCP server reads the password once at startup, so we must
    # restart cclear-mcp for the new password to take effect.
    info "Restarting cclear-mcp to apply new password..."
    read_into compose_flags < <(compose_args)
    docker compose "${compose_flags[@]}" restart cclear-mcp
    success "Password updated and service restarted for instance '${name}'"
    ;;

  up)
    if [[ -x "$CONFIG_HELPER" ]]; then
      "$CONFIG_HELPER" "$CONFIG_DIR"
    fi
    load_env
    ensure_vault_env
    if is_vault_mode; then
      prompt_vault_token
    fi
    ensure_tls_certs
    read_into compose_flags     < <(compose_args)
    read_into services < <(compose_services)
    adopt_legacy_resources
    if is_vault_mode; then
      fetch_vault_secrets
    fi
    docker compose "${compose_flags[@]}" up -d --remove-orphans "${services[@]}"

    report_and_provision
    ;;

  config)
    if [[ "${2:-}" == "show" ]]; then
      if [[ "${3:-}" == "--raw" || "${3:-}" == "-r" ]]; then
        header "Current Configuration (raw)"
        for f in "$CONFIG_DIR/cclear-instances.yaml" \
                 "$CONFIG_DIR/mcp-proxy-settings.yaml" \
                 "$CONFIG_DIR/deployment.env" \
                 "$CONFIG_DIR/vault.env"; do
          if [[ -f "$f" ]]; then
            printf "\n${BOLD}── %s${RESET}\n" "$(basename "$f")"
            if [[ "$(basename "$f")" == "vault.env" ]]; then
              sed '/^[[:space:]]*$/d' "$f"
              printf "  ${BOLD}%-14s${RESET} %s\n" "VAULT_TOKEN" "(prompted at runtime — never stored)"
            else
              sed 's/^\(\s*password:\s*\).*/\1********/' "$f"
            fi
          fi
        done
      else
        config_show
      fi
    else
      if [[ -x "$CONFIG_HELPER" ]]; then
        running=false
        stack_running && running=true
        snapshot="$(config_checksum)"
        CCLEAR_STACK_RUNNING="$running" "$CONFIG_HELPER" "$CONFIG_DIR" --reconfigure
        # Offer to apply changes to a running stack.
        if [[ "$running" == true ]] && [[ "$(config_checksum)" != "$snapshot" ]]; then
          warn "The stack is running — configuration changes apply after a restart."
          if [[ "$_IS_INTERACTIVE" == true ]]; then
            printf "${BOLD}Restart the stack now to apply changes?${RESET} [Y/n]: " >"$_TTY_OUT"
            read -r reply <"$_TTY_IN" || reply=""
            case "${reply:-Y}" in
              [Yy]*) do_restart ;;
              *)     info "Run ./cclear-mcp.sh restart to apply changes." ;;
            esac
          else
            info "Run ./cclear-mcp.sh restart to apply changes."
          fi
        fi
      fi
    fi
    ;;

  skills)
    if [[ ! -x "$SKILLS_HELPER" ]]; then
      err "Skills helper not found or not executable: $SKILLS_HELPER"
      exit 1
    fi
    shift
    if [[ $# -eq 0 ]]; then
      set -- list
    fi
    subcmd="$1"
    "$SKILLS_HELPER" "$CONFIG_DIR" "$@"
    if [[ "$subcmd" == "install" || "$subcmd" == "remove" ]]; then
      load_deployment_mode
      if [[ "$subcmd" == "install" ]] && ! is_skills_mode; then
        warn "Agent Skills is disabled — installed skills are not being served."
        printf "   Enable with: ./cclear-mcp.sh config   (Deployment Mode step)\n" >&2
      fi
      # The skills container only re-scans /skills on restart, and mcp-proxy
      for c in "$SKILLS_CONTAINER_NAME" "$PROXY_CONTAINER_NAME"; do
        if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "^${c}$"; then
          info "Restarting ${c} to pick up skill changes..."
          docker restart "$c" >/dev/null
          success "Restarted ${c}"
        fi
      done
    fi
    ;;

  down)
    load_env
    read_into compose_flags < <(compose_args)
    docker compose "${compose_flags[@]}" down --remove-orphans
    ;;

  restart)
    do_restart
    ;;

  status)
    load_env
    read_into compose_flags < <(compose_args)
    docker compose "${compose_flags[@]}" ps
    ;;

  logs)
    load_env
    read_into compose_flags < <(compose_args)
    shift
    docker compose "${compose_flags[@]}" logs "$@"
    ;;

  *)
    err "Unknown command: $cmd"
    usage
    exit 1
    ;;
esac
