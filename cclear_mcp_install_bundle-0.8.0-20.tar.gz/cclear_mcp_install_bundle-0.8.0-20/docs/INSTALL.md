# cClear MCP Installation

This guide walks through a reference installation of the cClear MCP stack using Docker Compose. The deployment approach shown here serves as a foundation that can be adapted for other deployment methods and environments. The stack consists of:

- **cclear-mcp** — the MCP server that connects to one or more cClear instances
- **Gateway** _(optional, recommended)_ — `nginx` (TLS termination) + `mcp-proxy` (OAuth2/OIDC authentication) in front of the MCP stack. Disable it to run without the gateway, in which case the MCP servers are published directly over plain HTTP. See **Step 5. Deployment Mode** below.
- **Agent Skills** _(optional)_ — a library of [Agent Skills](https://agentskills.io/home) (`load_skill` / `load_skill_resource`) served by the `agent-skills-mcp` container. See **Step 5. Deployment Mode** below.
- **vault-cli** _(optional)_ — fetches cClear passwords from HashiCorp Vault at startup

## Bundle Contents

```
cclear_mcp_install_bundle-<version>/
├── cclear-mcp.sh
├── compose/
│   ├── docker-compose.yml
│   ├── docker-compose.vault.yml
│   ├── docker-compose.standalone.yml
│   ├── docker-compose.standalone-skills.yml
│   ├── docker-compose.skills.yml
│   └── config/
│       ├── nginx.conf
│       ├── skills/            # empty — add skill packs here (see Step 5)
│       └── examples/
│           ├── cclear-instances.example.yaml
│           ├── mcp-proxy-settings.example.yaml
│           ├── mcp-proxy-settings.skills.example.yaml
│           ├── vault.env.example
│           └── deployment.env.example
├── docs/
│   └── INSTALL.md
└── scripts/
    ├── cclear-config.sh
    ├── skills-pack.sh
    ├── term.sh
    └── tls-self-sign.sh
```

---

## Prerequisites

On the host machine where you will run the cClear MCP:

- Ensure Docker Engine 24.0.2+ and Docker Compose v2.20.2+ are installed on your host machine
- Port **443** available on the host machine
    - By default, nginx exposes HTTPS on port 443. You can choose a different host port by updating the `ports` section in `compose/docker-compose.yml`.
    - Without the gateway, `cclear-mcp` is published on port **8000** instead (and `agent-skills-mcp` on **8001** when Agent Skills is enabled).
- Access to the image registry `cpacket.jfrog.io`. This is required to retrieve the cclear-mcp, mcp-proxy, and (when Agent Skills is enabled) agent-skills-mcp docker images
    - If Docker cannot pull images due to authentication, you may see an error similar to:

      ```text
      Error response from daemon: Head "https://cpacket.jfrog.io/v2/ai-workflows-docker/cpacket/cclear-mcp/manifests/main": unknown: Authentication is required
      ```

      Fix this by authenticating to the registry before starting the stack:

      ```bash
      docker login cpacket.jfrog.io
      ```

---

## Quick Start

All commands are run from the bundle root directory (where `cclear-mcp.sh` lives).

```bash
./cclear-mcp.sh up
```

On first run, the launcher automatically opens a configuration wizard to collect your cClear connection details and write the required config files to `compose/config/`. Once configured, `up` starts the full stack.

To re-run the wizard at any time:

```bash
./cclear-mcp.sh config
```

---

## Configuration

Config files are written to `compose/config/` by the wizard. Templates are in `compose/config/examples/` for reference.

### Step 1. cClear Instances — `compose/config/cclear-instances.yaml`

This is the primary configuration file. It defines one or more cClear instances to connect to. The wizard creates it interactively; here is a reference example:

```yaml
cclear_instances:
  cclear-prod:
    host: 10.51.42.126
    port: 443
    username: cpacket
    ssl: true
    verify_ssl: false
    timeout: 600
    auth_mode: docker-secret
    password_file: /secure/cclear-password-0

  cclear-staging:
    host: 10.51.42.114
    port: 443
    username: cpacket
    ssl: true
    verify_ssl: false
    timeout: 600
    auth_mode: docker-secret
    password_file: /secure/cclear-password-1
    vault_secret_path: cclear/staging/password
    vault_secret_field: value
```

#### Fields

| Field | Description |
|---|---|
| `host` | Hostname or IP of the cClear instance |
| `port` | Port (default: `443`) |
| `username` | cClear username |
| `auth_mode` | How the password is supplied — `docker-secret` or `env` |
| `password` | Plain text password (only when `auth_mode: env`) |
| `password_file` | Path inside the container for the password file |
| `vault_secret_path` | _(optional)_ Vault path to fetch the password from |
| `vault_secret_field` | _(optional)_ Field within the Vault secret (default: `value`) |

#### Password / Auth Modes

**Option A — `env`**
Password stored in plain text in the YAML config.
```yaml
auth_mode: env
password: your-password-here
```

**Option B — `docker-secret` (manual prompt)**
The launcher prompts for the password on `up` and injects it into an in-memory tmpfs volume. The password is never written to disk.
```yaml
auth_mode: docker-secret
password_file: /secure/cclear-password-0
```

**Option C — `docker-secret` with Vault**
Password fetched automatically from HashiCorp Vault at startup. Requires `vault.env` — see [Step 3](#step-3-vault-configuration--composeconfigvaultenv).
```yaml
auth_mode: docker-secret
password_file: /secure/cclear-password-0
vault_secret_path: cclear/prod/password
vault_secret_field: value
```

---

### Step 2. MCP Proxy — `compose/config/mcp-proxy-settings.yaml`

The MCP Proxy service runs behind nginx and is responsible for authenticating and authorizing MCP clients connecting to the MCP servers. Authentication settings are provided through this configuration file at runtime.

On first run the file is created automatically from one of two templates, depending on your Agent Skills choice (Step 5):

- `mcp-proxy-settings.example.yaml` — proxies `cclear-mcp` only
- `mcp-proxy-settings.skills.example.yaml` — proxies **both** `cclear-mcp` and `agent-skills-mcp`

After that the file is yours to edit — `auth`, logging, and the public URL are preserved across runs. The only part kept in sync automatically is the Agent Skills entry under `proxied_servers`: when you toggle `USE_SKILLS` (Step 5) and re-run `config` or `up`, the `agent-skills-mcp` server is added or removed to match. Everything else you customize is left untouched.

| Field | Description |
|---|---|
| `service.url` | Public URL clients connect to (default: `https://localhost/`) |
| `auth.enable` | Set to `true` to enforce OAuth2/OIDC authentication (`false` disables it) |
| `auth.issuer` | OIDC issuer URL (e.g. Google, Okta) |
| `proxied_servers[]` | Backend MCP servers to aggregate — each has a `name`, `prefix`, and internal `url`. The `cclear` and `skills` entries are managed for you. |

> The `agent-skills-mcp` entry in `proxied_servers` is added/removed automatically based on `USE_SKILLS` — you don't need to edit it by hand.

---

### Step 3. Vault Configuration — `compose/config/vault.env`

Only required if you choose **Option C** in Step 1 (`docker-secret` with Vault). The wizard prompts for these values automatically when Vault is selected.

| Variable | Description |
|---|---|
| `VAULT_ADDR` | Vault server URL |
| `VAULT_MOUNT` | KV mount path (e.g. `kv`) |

> **Security:** The Vault token is **never stored on disk**. It is prompted interactively (silent input) each time the stack starts and passed to the container via the environment. This prevents token exposure in config files, shell history, or logs.

> Per-instance `vault_secret_path` and `vault_secret_field` are configured in `cclear-instances.yaml` alongside each instance.

---

### Step 4. TLS Certificates — `compose/config/tls/`

> Only required when the **gateway** is enabled (see **Step 5**). Without the gateway there is no nginx, so no TLS certificates are needed.

nginx requires TLS certificates at startup. If they don't exist, `./cclear-mcp.sh up` will prompt you to generate self-signed certs automatically.

To generate them manually beforehand:

```bash
./scripts/tls-self-sign.sh [hostname]
```

This creates `compose/config/tls/server.crt` and `compose/config/tls/server.key`.

> **Note:** Self-signed certificates will trigger browser/client warnings. For production, replace them with certificates from a trusted CA.

---

### Step 5. Deployment Mode — `compose/config/deployment.env`

Two independent toggles control the stack. The wizard prompts for both; the choices are stored as `USE_GATEWAY` and `USE_SKILLS` in `deployment.env`.

**Gateway** — whether to run `nginx` (TLS) + `mcp-proxy` (OAuth2/OIDC auth) in front of the MCP servers.

| `USE_GATEWAY` | Request flow | When to use |
|---|---|---|
| `true` _(default)_ | nginx → mcp-proxy → cclear-mcp | Recommended — terminates TLS and authenticates clients |
| `false` | client → cclear-mcp (`:8000`) | Use only when TLS and authentication are handled by another gateway in front |

With the gateway disabled, neither `nginx` nor `mcp-proxy` is started and `cclear-mcp` is published directly on host port `8000` over plain HTTP.

To switch later, re-run `./cclear-mcp.sh config`, or set `USE_GATEWAY=true` / `USE_GATEWAY=false` in `compose/config/deployment.env` and restart the stack.

> **Security:** Disabling the gateway removes both TLS and the mcp-proxy OAuth2/OIDC layer. Only use it when an upstream gateway already secures clients.

#### Agent Skills (optional)

**Agent Skills** runs as the `agent-skills-mcp` container that serves the `load_skill` and `load_skill_resource` tools from `compose/config/skills/`. It is independent of the gateway toggle. The wizard prompts for this; the choice is stored as `USE_SKILLS` in `deployment.env`.

> **When to use it:** Prefer your agent's **native** Agent Skills support if it has any — enable `agent-skills-mcp` only when your agent can't load skills on its own.

| `USE_SKILLS` | Effect |
|---|---|
| `true` | Start the `agent-skills-mcp` container alongside `cclear-mcp` |
| `false` _(default)_ | `cclear-mcp` only |

How clients reach the skills depends on the gateway toggle:

| Gateway | Skills | Client connects to |
|---|---|---|
| `true` | `true` | `https://<host>/` — `mcp-proxy` aggregates **both** servers (prefixes `cclear` and `skills`) |
| `false` | `true` | `http://<host>:8000/mcp` (cClear) **and** `http://<host>:8001/mcp` (skills) — two endpoints |

Skill packs follow the [Agent Skills](https://agentskills.io/home) spec and are mounted into the container from `compose/config/skills/` (the `agent-skills-mcp` image ships none of its own), so **this directory ships empty**. Each subdirectory containing a `SKILL.md` is one skill:

```
skills/
  my-skill/
    SKILL.md
    references/
```

The mount is read-only and re-scanned when `agent-skills-mcp` restarts.

To enable later, re-run `./cclear-mcp.sh config`, or set `USE_SKILLS=true` in `compose/config/deployment.env` and restart the stack.

#### Installing Skill Packs

The wizard offers to install a skill pack when Agent Skills is enabled and `compose/config/skills/` is empty. You can also manage packs at any time with the `skills` command:

```bash
# Online — download from the cPacket Artifactory (latest version):
./cclear-mcp.sh skills install

# Online — a specific pack and/or version:
./cclear-mcp.sh skills install cclear-core --version 26.06.0

# Offline — install from a local .zip provided by cPacket:
./cclear-mcp.sh skills install --file /path/to/cclear-core-26.06.0.zip

# Download only (no install) — keeps the zip in compose/config/skills-downloads/
# for copying to an offline host:
./cclear-mcp.sh skills download cclear-core --version 26.06.0

# Show installed packs / remove the installed pack:
./cclear-mcp.sh skills list
./cclear-mcp.sh skills remove
```

Online downloads come from `https://cpacket.jfrog.io/artifactory/ai-workflows-knowledge` and reuse your `docker login cpacket.jfrog.io` credentials (from `~/.docker/config.json`) — the same login already required for pulling the container images. The command never prompts for credentials; if authentication fails it exits and asks you to run `docker login cpacket.jfrog.io` first.

Only one pack can be installed at a time — installing a new version replaces the previous one, and installing a different pack requires `--force` (which replaces the installed pack). Skills you added manually are left untouched. If the `agent-skills-mcp` container is running, it is restarted automatically after an install or remove so the changes take effect.

---

## Managing the Stack

All commands are run from the bundle root directory.

| Command | Description |
|---|---|
| `./cclear-mcp.sh up` | Start the stack (runs config wizard if needed) |
| `./cclear-mcp.sh down` | Stop the stack |
| `./cclear-mcp.sh restart` | Restart the stack |
| `./cclear-mcp.sh status` | Show container status |
| `./cclear-mcp.sh logs` | Show logs (pass `-- [service] [-f]` for options) |
| `./cclear-mcp.sh config` | Re-run the configuration wizard |
| `./cclear-mcp.sh skills install [pack] [--version <v>] [--file <zip>]` | Install an Agent Skill pack (Artifactory or local file) |
| `./cclear-mcp.sh skills download [pack] [--version <v>]` | Download a pack zip without installing (offline transfer) |
| `./cclear-mcp.sh skills list` | Show installed skill packs |
| `./cclear-mcp.sh skills remove [pack]` | Remove the installed skill pack |
| `./cclear-mcp.sh help` | Show available commands |

---

## Connecting to cClear MCP

Once the stack is running, configure your MCP clients to connect:

- **With the gateway** — `https://<host>/mcp` (port 443 by default).
- **Without the gateway** — `http://<host>:8000/mcp` for cClear, and `http://<host>:8001/mcp` for Agent Skills (when enabled).

---

## Verifying Images (Optional)

To confirm images are available locally before starting:

```bash
docker images | grep -E 'cclear-mcp|agent-skills-mcp|mcp-proxy|nginx|vault'
```
Docker Compose will pull any missing images automatically on first run.
